import React, { useState, useEffect, useRef } from "react";
import { Idol, PoojaItem, CartItem, Order, AppState, AppSettings, AuthUser } from "./types";
import { OmSoundSynth } from "./components/SoundSynth";
import Storefront from "./components/Storefront";
import AdminPanel from "./components/AdminPanel";
import AuthModal from "./components/AuthModal";
import { Sparkles, Play, Square, RefreshCw, Volume2, VolumeX, Shield, Key, Heart, Users, Compass, Eye, AlertCircle, Search, SlidersHorizontal, User, LogOut, PackageCheck } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [appState, setAppState] = useState<AppState>({ idols: [], poojaItems: [], orders: [], lastUpdated: 0 });
  const [isOmPlaying, setIsOmPlaying] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<"online" | "syncing" | "offline">("online");
  const [syncCount, setSyncCount] = useState(0);

  // Global search parameters lifted to Navbar as requested
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStyle, setSelectedStyle] = useState("All");
  const [priceRange, setPriceRange] = useState(15000);
  const [selectedQuality, setSelectedQuality] = useState("All");
  const [showFilters, setShowFilters] = useState(false);

  // User auth credentials session
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("vighnaharta_user");
      return stored ? JSON.parse(stored) : null;
    }
    return null;
  });
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Admin routing query detector
  const [isAdminMode, setIsAdminMode] = useState(() => {
    if (typeof window !== "undefined") {
      return window.location.search.includes("view=admin") || 
             window.location.search.includes("role=admin") ||
             window.location.pathname === "/admin";
    }
    return false;
  });

  // Synth sound ref
  const synthRef = useRef<OmSoundSynth | null>(null);

  // Initialize Audio Synth
  useEffect(() => {
    synthRef.current = new OmSoundSynth();
    return () => {
      // Clean up sound on unmount
      if (synthRef.current?.isPlaying) {
        synthRef.current.toggle();
      }
    };
  }, []);

  // Sync API Fetchers
  const fetchState = async () => {
    try {
      setIsSyncing(true);
      setConnectionStatus("syncing");
      const res = await fetch("/api/state");
      if (res.ok) {
        const data: AppState = await res.json();
        setAppState(data);
        setConnectionStatus("online");
        setSyncCount(prev => prev + 1);
      } else {
        setConnectionStatus("offline");
      }
    } catch (e) {
      console.error("Failed to connect to Express backend:", e);
      setConnectionStatus("offline");
    } finally {
      setIsSyncing(false);
    }
  };

  // Run Poll check to synchronize state in real-time
  useEffect(() => {
    fetchState();
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/sync?lastUpdated=${appState.lastUpdated || 0}`);
        if (res.ok) {
          const syncCheck = await res.json();
          if (syncCheck.updated && syncCheck.state) {
            setAppState(syncCheck.state);
            setSyncCount(prev => prev + 1);
            setConnectionStatus("online");
          }
        }
      } catch (err) {
        console.warn("Retrying state sync fetch...", err);
        setConnectionStatus("offline");
      }
    }, 2500);

    return () => clearInterval(interval);
  }, [appState.lastUpdated]);

  // Google popup OAuth receiver logic
  useEffect(() => {
    const handleGoogleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        const devUser = event.data.user;
        const completeInfo: AuthUser = {
          email: devUser.email,
          displayName: devUser.displayName || devUser.email.split("@")[0],
          token: "session-google-" + Date.now()
        };
        setCurrentUser(completeInfo);
        localStorage.setItem("vighnaharta_user", JSON.stringify(completeInfo));
        setShowAuthModal(false);
      }
    };
    window.addEventListener('message', handleGoogleMessage);
    return () => window.removeEventListener('message', handleGoogleMessage);
  }, []);

  // OM Sound trigger
  const handleToggleOm = () => {
    if (synthRef.current) {
      const state = synthRef.current.toggle();
      setIsOmPlaying(state);
    }
  };

  // Handlers for session
  const handleAuthSuccess = (user: AuthUser) => {
    setCurrentUser(user);
    localStorage.setItem("vighnaharta_user", JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("vighnaharta_user");
  };

  // POST order handler
  const handlePlaceOrder = async (cart: CartItem): Promise<Order | null> => {
    try {
      const selectedPoojaItems = cart.poojaItems
        .filter(p => p.quantity > 0)
        .map(p => ({
          id: p.item.id,
          quantity: p.quantity
        }));

      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          deviceId: currentUser ? `${currentUser.displayName}` : "Standalone Devotee",
          customerName: cart.customerName,
          customerPhone: cart.customerPhone,
          idolId: cart.idol.id,
          poojaItems: selectedPoojaItems,
          deliveryType: cart.deliveryType,
          deliveryAddress: cart.deliveryAddress,
          paymentType: cart.paymentType
        })
      });

      if (res.ok) {
        const payload = await res.json();
        if (payload.success && payload.order) {
          // Instantly sync state
          setAppState(payload.state);
          return payload.order;
        }
      } else {
        const errData = await res.json();
        alert(`Booking Failed: ${errData.error || "Please verify Ganesha stock."}`);
      }
    } catch (e) {
      console.error("Order payload submission fault:", e);
      alert("Failsafe: error communicating with secure billing vault.");
    }
    return null;
  };

  // ADMIN API triggers
  const handleAddUpdateIdol = async (idol: Idol) => {
    try {
      const res = await fetch("/api/idols", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(idol)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          fetchState();
        }
      }
    } catch (e) {
      console.error("Failed to sync Ganesha inventory changes:", e);
    }
  };

  const handleDeleteIdol = async (id: string) => {
    try {
      const res = await fetch(`/api/idols/${id}`, {
        method: "DELETE"
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          fetchState();
        }
      }
    } catch (e) {
      console.error("Failed to delete Ganesha:", e);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: "completed" | "cancelled") => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          fetchState();
        }
      }
    } catch (e) {
      console.error("Failed to update status on server:", e);
    }
  };

  const handleUpdatePoojaItemPrice = async (id: string, price: number) => {
    setAppState(prev => {
      const nextPooja = prev.poojaItems.map(p => p.id === id ? { ...p, price } : p);
      return {
        ...prev,
        poojaItems: nextPooja,
        lastUpdated: Date.now()
      };
    });
  };

  const handleUpdateSettings = async (settings: AppSettings) => {
    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          fetchState();
          alert("Administrative configurations applied successfully!");
        }
      }
    } catch (e) {
      console.error("Failed to save credentials:", e);
    }
  };

  return (
    <div className="h-screen h-[100dvh] max-h-screen bg-slate-950 flex flex-col relative text-white antialiased overflow-hidden">
      {/* Auric ambient light spots */}
      <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-yellow-400/5 rounded-full blur-3xl pointer-events-none z-0" />
      <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-orange-600/5 rounded-full blur-3xl pointer-events-none z-0" />

      {/* HORIZONTAL NAVBAR WITH INTEGRATED GLOBAL SEARCH & FILTERS */}
      <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-900/85 backdrop-blur-md px-3 md:px-6 py-2 md:py-3 flex flex-col md:flex-row items-center justify-between gap-2.5 md:gap-4 shadow-xl select-none">
        
        {/* Brand Logo & OM Sound Indicator (Sound logo only set, no name text!) */}
        <div className="flex items-center justify-between w-full md:w-auto gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-xl animate-pulse">🌺</span>
            <div className="flex flex-col">
              <h1 className="font-sans font-black text-yellow-400 text-xs md:text-base leading-none tracking-tight">
                Vighnaharta Utsav
              </h1>
              <span className="text-[8px] md:text-[9px] uppercase font-mono tracking-widest text-orange-450 font-extrabold mt-0.5">
                Akurdi divine portal
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 md:hidden">
            <button
              onClick={handleToggleOm}
              className={`p-2 rounded-full border transition-all cursor-pointer ${
                isOmPlaying
                  ? "bg-yellow-400 border-yellow-300 text-orange-950 shadow-md shadow-yellow-400/20 active:scale-95"
                  : "bg-white/5 border-white/10 text-white hover:bg-white/15"
              }`}
            >
              {isOmPlaying ? <Volume2 className="w-3.5 h-3.5 animate-bounce" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>
            
            {currentUser ? (
              <span className="h-1.5 w-1.5 rounded-full bg-green-400 animate-pulse" />
            ) : (
              <button
                onClick={() => setShowAuthModal(true)}
                className="p-1.5 rounded-full bg-yellow-400 text-orange-950 font-bold active:scale-95 transition-all"
              >
                <User className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Dynamic Search & Filters Area embedded directly in the Navbar */}
        {!isAdminMode && (
          <div className="flex-1 max-w-xl w-full flex items-center gap-1.5">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2 w-3.5 h-3.5 text-white/50" />
              <input
                type="text"
                placeholder="Search Lord Ganesha (Material, color...)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-black/45 border border-white/15 text-white placeholder-white/50 rounded-xl pl-8 pr-3 py-1.5 text-[11px] outline-none focus:ring-1 focus:ring-yellow-400 font-medium transition-all"
              />
            </div>

            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border text-[11px] font-bold transition-all cursor-pointer ${
                showFilters || selectedStyle !== "All" || selectedQuality !== "All"
                  ? "bg-yellow-400 border-white/10 text-orange-950"
                  : "bg-white/5 border-white/10 text-white hover:bg-white/10"
              }`}
            >
              <SlidersHorizontal className="w-3 h-3 font-bold" />
              <span className="hidden sm:inline">Filters</span>
            </button>

            {/* Quick reset tag indicator */}
            {(selectedStyle !== "All" || selectedQuality !== "All" || priceRange < 15000) && (
              <span className="relative flex h-2 w-2 -ml-2 -mt-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-yellow-500" />
              </span>
            )}
          </div>
        )}

        {/* Actions Controls (Om sound logo, User Authentication flow SSO) */}
        <div className="hidden md:flex items-center gap-3">
          {/* Web Mode Selector: Switch between User and Admin Portal */}
          <div className="bg-white/5 border border-white/10 p-1 rounded-2xl flex gap-1 select-none text-[10.5px] font-sans font-bold">
            <button
              onClick={() => {
                setIsAdminMode(false);
                if (typeof window !== "undefined") {
                  const url = new URL(window.location.href);
                  url.searchParams.delete("view");
                  url.searchParams.delete("role");
                  window.history.pushState({}, "", url.pathname + url.search);
                }
              }}
              className={`px-3 py-1.5 rounded-xl cursor-pointer transition-all flex items-center gap-1 ${
                !isAdminMode
                  ? "bg-yellow-400 text-orange-950 font-black shadow-md border border-yellow-300"
                  : "text-white/70 hover:text-white"
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Devotee Hub</span>
            </button>
            <button
              onClick={() => {
                setIsAdminMode(true);
                if (typeof window !== "undefined") {
                  const url = new URL(window.location.href);
                  url.searchParams.set("view", "admin");
                  window.history.pushState({}, "", url.pathname + url.search);
                }
              }}
              className={`px-3 py-1.5 rounded-xl cursor-pointer transition-all flex items-center gap-1 ${
                isAdminMode
                  ? "bg-orange-500 text-white font-black shadow-md border border-orange-455"
                  : "text-white/70 hover:text-white"
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Panel</span>
            </button>
          </div>

          {/* Audio Synthesizer Toggle - ONLY SHOW LOGO / SOUND ICON */}
          <button
            onClick={handleToggleOm}
            className={`p-2.5 rounded-2xl border transition-all cursor-pointer ${
              isOmPlaying
                ? "bg-yellow-400 border-yellow-300 text-orange-950 shadow-md shadow-yellow-400/20 active:scale-95"
                : "bg-white/5 border-white/10 text-white hover:bg-white/15"
            }`}
            title="Om meditation sound volume"
          >
            {isOmPlaying ? <Volume2 className="w-4.5 h-4.5 animate-bounce" /> : <VolumeX className="w-4.5 h-4.5" />}
          </button>

          {/* User Sign In / Profile dropdown details */}
          {currentUser ? (
            <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-3 py-1.5 rounded-2xl">
              <span className="inline-flex items-center justify-center p-1.5 bg-yellow-400 text-orange-950 rounded-full text-[10px] font-black leading-none">
                🌺
              </span>
              <div className="flex flex-col text-left">
                <span className="text-[10px] text-white/90 font-bold whitespace-nowrap leading-none max-w-[80px] overflow-hidden text-ellipsis font-sans">
                  {currentUser.displayName}
                </span>
                <span className="text-[8px] text-white/55 font-mono">
                  {currentUser.email ? "Gmail Account" : "Phone Connected"}
                </span>
              </div>
              <button
                onClick={handleLogout}
                className="text-white/60 hover:text-pink-400 p-1 rounded-md transition-all font-bold"
                title="Log out devotee"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowAuthModal(true)}
              className="bg-yellow-400 hover:bg-yellow-350 active:scale-95 transition-all text-orange-950 font-black text-xs px-4 py-2 rounded-2xl flex items-center gap-1.5 cursor-pointer shadow-md border border-yellow-300"
            >
              <User className="w-4 h-4" />
              <span>Join Devotee Hub</span>
            </button>
          )}

          {/* Connection poll status light */}
          <div className="flex items-center gap-1 border border-white/10 px-2 py-2 rounded-2xl bg-black/10">
            <span className={`w-2 h-2 rounded-full ${connectionStatus === "online" ? "bg-green-500" : connectionStatus === "syncing" ? "bg-yellow-500 animate-pulse" : "bg-red-500"}`} />
            <span className="text-[9px] uppercase font-mono text-white/50 tracking-wider">Poll: {syncCount}</span>
          </div>
        </div>
      </header>

      {/* Main app panel layout: Wide single container viewport */}
      <main className="flex-1 overflow-hidden p-0 md:p-4 relative z-10 flex flex-col">
        <AnimatePresence mode="wait">
          {isAdminMode ? (
            /* Layout A: Encapsulated Admin panel */
            <motion.div
              key="admin-panel"
              initial={{ opacity: 0, scale: 0.99 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="h-full flex flex-col"
            >
              <div className="flex-1 overflow-hidden bg-slate-900/60 md:border md:border-white/10 rounded-none md:rounded-3xl p-1 md:shadow-2xl backdrop-blur-md">
                <AdminPanel
                  appState={appState}
                  onAddUpdateIdol={handleAddUpdateIdol}
                  onDeleteIdol={handleDeleteIdol}
                  onUpdateOrderStatus={handleUpdateOrderStatus}
                  onUpdatePoojaItemPrice={handleUpdatePoojaItemPrice}
                  onUpdateSettings={handleUpdateSettings}
                />
              </div>
            </motion.div>
          ) : (
            /* Layout B: Clean Native Devotional Catalog Storefront (full single screen view!) */
            <motion.div
              key="customer-storefront"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="h-full flex flex-col"
            >
              <div className="flex-1 overflow-hidden bg-slate-900/40 md:border md:border-white/10 rounded-none md:rounded-3xl p-2 md:p-4 flex flex-col md:shadow-2xl backdrop-blur-md">
                <Storefront
                  appState={appState}
                  onPlaceOrder={handlePlaceOrder}
                  deviceId={currentUser ? `User-${currentUser.displayName}` : "devotee-browser"}
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                  selectedStyle={selectedStyle}
                  setSelectedStyle={setSelectedStyle}
                  priceRange={priceRange}
                  setPriceRange={setPriceRange}
                  selectedQuality={selectedQuality}
                  setSelectedQuality={setSelectedQuality}
                  showFilters={showFilters}
                  setShowFilters={setShowFilters}
                  currentUser={currentUser}
                  onRequestAuth={() => setShowAuthModal(true)}
                  isOmPlaying={isOmPlaying}
                  onToggleOm={handleToggleOm}
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* RENDER USER AUTHENTICATION GATEWAY POPUP MODAL */}
      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onAuthSuccess={handleAuthSuccess}
        />
      )}

      {/* Global Bottom Credit Watermark line */}
      <footer className="hidden md:block py-2.5 text-center text-[10px] font-mono text-white/60 tracking-wider border-t border-white/10 bg-slate-900/80 backdrop-blur z-40 select-none">
        🕉️ Vakratunda Mahakaya Suryakoti Samaprabha • Nirvighnam Kuru Me Deva Sarvakaryeshu Sarvada 🕉️
      </footer>
    </div>
  );
}
