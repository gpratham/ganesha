import React, { useState } from "react";
import { X, Mail, Phone, ShieldCheck, Sparkles, LogIn, Lock, ArrowRight } from "lucide-react";
import { AuthUser } from "../types";
import { motion } from "motion/react";

interface AuthModalProps {
  onClose: () => void;
  onAuthSuccess: (user: AuthUser) => void;
}

export default function AuthModal({ onClose, onAuthSuccess }: AuthModalProps) {
  const [authType, setAuthType] = useState<"google" | "email" | "phone">("email");
  const [emailValue, setEmailValue] = useState("");
  const [phoneValue, setPhoneValue] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [debugOtp, setDebugOtp] = useState("");

  // Handler: Google OAuth SSO (Popup client)
  const handleGoogleOAuth = async () => {
    try {
      setIsSubmitting(true);
      setErrorMessage("");
      
      const callbackUrl = `${window.location.origin}/auth/callback`;
      const res = await fetch(`/api/auth/google/url?redirect_uri=${encodeURIComponent(callbackUrl)}`);
      if (!res.ok) throw new Error("Could not fetch secure Google OAuth gateway URL");
      
      const { url } = await res.json();
      
      // Open the Google provider directly in popup window
      const authWindow = window.open(
        url,
        "google_oauth_popup",
        "width=500,height=600,top=100,left=100"
      );

      if (!authWindow) {
        setErrorMessage("Popup blocker active. Please permit popup windows to log in with Gmail.");
      }
    } catch (e: any) {
      setErrorMessage(e.message || "Failed to launch SSO authentication");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handler: Send OTP for Email or Phone
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage("");
    
    const value = authType === "email" ? emailValue : phoneValue;
    if (!value) {
      setErrorMessage(`${authType === "email" ? "Email" : "Phone number"} field is required.`);
      setIsSubmitting(false);
      return;
    }

    try {
      const res = await fetch("/api/auth/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: authType, value })
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Failed securely dispatching OTP");
      }

      const outcome = await res.json();
      setOtpSent(true);
      if (outcome.code) {
        setDebugOtp(outcome.code); // Store code so user knows what to enter in this sandboxed environment!
      }
    } catch (e: any) {
      setErrorMessage(e.message || "Something went wrong sending security OTP.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handler: Verify OTP
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode) {
      setErrorMessage("Please input the 6-digit confirmation code.");
      return;
    }

    setIsSubmitting(true);
    setErrorMessage("");
    const value = authType === "email" ? emailValue : phoneValue;

    try {
      const res = await fetch("/api/auth/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: authType, value, code: otpCode })
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Invalid security code verification");
      }

      const outcome = await res.json();
      if (outcome.success && outcome.user) {
        onAuthSuccess({
          ...outcome.user,
          token: outcome.token
        });
        onClose();
      }
    } catch (e: any) {
      setErrorMessage(e.message || "Authentication attempt rejected.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-[999] flex items-center justify-center p-4">
      <div className="bg-purple-950/80 border border-white/20 rounded-3xl w-full max-w-[400px] shadow-2xl relative overflow-hidden backdrop-blur-md text-white p-6 md:p-8 animate-fadeIn">
        {/* Subtle Auric Background Glow */}
        <div className="absolute top-0 left-0 w-32 h-32 bg-yellow-400/15 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-32 h-32 bg-orange-500/10 rounded-full blur-2xl pointer-events-none" />

        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white/60 hover:text-white bg-white/10 p-1.5 rounded-full hover:bg-white/20 transition-all cursor-pointer border border-white/5"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="text-center mb-6">
          <span className="inline-flex p-3 bg-yellow-405/10 bg-yellow-400/10 border border-yellow-300/30 rounded-full text-yellow-300 mb-3 animate-pulse">
            <Lock className="w-6 h-6 stroke-[1.5]" />
          </span>
          <h2 className="text-lg font-black font-sans text-yellow-300 tracking-tight">Devotee Hub secure login</h2>
          <p className="text-[10px] text-white/70 font-mono mt-1 leading-normal uppercase">
            Sign up to track personal booking history
          </p>
        </div>

        {errorMessage && (
          <div className="p-3 bg-pink-500/15 border border-pink-500/20 text-pink-300 font-mono text-[10px] rounded-xl mb-4 leading-normal text-center">
            ⚠️ {errorMessage}
          </div>
        )}

        {/* Authentication Modes Tabs */}
        {!otpSent && (
          <div className="flex bg-black/40 p-1 rounded-xl border border-white/10 gap-1 text-[10px] font-mono font-bold mb-5 select-none">
            <button
              onClick={() => setAuthType("email")}
              className={`flex-1 py-1.5 rounded-lg text-center transition-all cursor-pointer ${
                authType === "email" ? "bg-yellow-400 text-orange-950 px-2 font-extrabold" : "text-white/60 hover:text-white"
              }`}
            >
              Gmail OTP ID
            </button>
            <button
              onClick={() => setAuthType("phone")}
              className={`flex-1 py-1.5 rounded-lg text-center transition-all cursor-pointer ${
                authType === "phone" ? "bg-yellow-400 text-orange-950 px-2 font-extrabold" : "text-white/60 hover:text-white"
              }`}
            >
              Phone OTP
            </button>
            <button
              onClick={() => {
                setAuthType("google");
                handleGoogleOAuth();
              }}
              className={`flex-1 py-1.5 rounded-lg text-center transition-all cursor-pointer ${
                authType === "google" ? "bg-yellow-400 text-orange-950 px-2 font-extrabold" : "text-white/60 hover:text-white"
              }`}
            >
              Google SSO
            </button>
          </div>
        )}

        {/* FORM 1: OTP Input state */}
        {otpSent ? (
          <form onSubmit={handleVerifyOtp} className="space-y-4">
            <div className="bg-green-500/10 border border-green-500/25 rounded-2xl p-3.5 space-y-1">
              <span className="text-[9px] uppercase tracking-wider font-extrabold text-green-400 block font-mono">
                🔒 Security system locked
              </span>
              <p className="text-[10px] text-white/80 leading-normal font-sans">
                A verification code was dispatched to <strong className="text-white font-mono">{authType === "email" ? emailValue : phoneValue}</strong>.
              </p>
              {debugOtp && (
                <div className="mt-1.5 p-1 bg-yellow-400/20 text-yellow-350 border border-yellow-300/25 rounded text-center text-[11px] font-mono font-bold">
                  🗝️ Fast Access OTP: {debugOtp}
                </div>
              )}
            </div>

            <div className="space-y-1">
              <label className="block text-[9px] uppercase font-bold tracking-widest text-yellow-300/80">Enter 6-Digit OTP</label>
              <input
                type="text"
                required
                maxLength={6}
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/[^0-9]/g, ""))}
                placeholder="e.g. 123456"
                className="w-full bg-black/45 border border-white/15 p-2 rounded-xl text-center text-sm font-mono text-white outline-none focus:ring-1 focus:ring-yellow-400"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-yellow-400 hover:bg-yellow-300 text-orange-950 font-black py-2.5 rounded-xl text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50"
            >
              <LogIn className="w-4 h-4" />
              <span>{isSubmitting ? "Verifying Token..." : "Validate & Log In"}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setOtpSent(false);
                setOtpCode("");
              }}
              className="text-[10px] text-white/50 hover:text-white font-mono block mx-auto underline mt-2"
            >
              Send code again
            </button>
          </form>
        ) : authType === "google" ? (
          /* FORM 2: Google accounts authorization CTA */
          <div className="space-y-4">
            <div className="p-4 bg-black/35 rounded-2xl border border-white/10 text-center space-y-2">
              <p className="text-[11px] leading-relaxed text-white/80">
                SSO popup window connects with Google Accounts directly to complete secure Gmail signup.
              </p>
              <button
                onClick={handleGoogleOAuth}
                disabled={isSubmitting}
                className="mx-auto flex items-center justify-center gap-2 bg-white text-slate-800 font-extrabold px-5 py-2.5 rounded-xl border border-slate-300 text-xs shadow-md shadow-white/5 hover:bg-slate-50 transition-all cursor-pointer"
              >
                <svg className="h-4" viewBox="0 0 24 24" width="16" height="16" xmlns="http://www.w3.org/2000/svg">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335"/>
                </svg>
                <span>Authorize with Google</span>
              </button>
            </div>
            <p className="text-[9px] text-white/50 text-center leading-normal">
              OAuth token establishes immediate cloud membership. We value your security.
            </p>
          </div>
        ) : (
          /* FORM 3: Normal Email or Phone dispatch triggers */
          <form onSubmit={handleSendOtp} className="space-y-4">
            {authType === "email" ? (
              <div className="space-y-1 animate-fadeIn">
                <label className="block text-[9px] uppercase font-bold tracking-widest text-yellow-300/80">Gmail Account Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-white/50" />
                  <input
                    type="email"
                    required
                    placeholder="e.g. yourname@gmail.com"
                    value={emailValue}
                    onChange={(e) => setEmailValue(e.target.value)}
                    className="w-full bg-black/45 border border-white/15 p-2 rounded-xl pl-9 text-xs font-mono text-white outline-none focus:ring-1 focus:ring-yellow-400"
                  />
                </div>
                <span className="text-[8px] text-white/40 block mt-0.5">Secure verification code will generate in backend for checkout access.</span>
              </div>
            ) : (
              <div className="space-y-1 animate-fadeIn">
                <label className="block text-[9px] uppercase font-bold tracking-widest text-yellow-300/80">Mobile Phone Line</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-2.5 w-4 h-4 text-white/50" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. 919876543210"
                    value={phoneValue}
                    onChange={(e) => setPhoneValue(e.target.value.replace(/[^0-9]/g, ""))}
                    className="w-full bg-black/45 border border-white/15 p-2 rounded-xl pl-9 text-xs font-mono text-white outline-none focus:ring-1 focus:ring-yellow-400"
                  />
                </div>
                <span className="text-[8px] text-white/40 block mt-0.5">Provide digits with region code to trigger SMS/WhatsApp bill dispatches.</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-yellow-400 hover:bg-yellow-300 text-orange-950 font-black py-2.5 rounded-xl text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50"
            >
              <span>{isSubmitting ? "Requesting security access..." : "Dispatch secure code"}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
