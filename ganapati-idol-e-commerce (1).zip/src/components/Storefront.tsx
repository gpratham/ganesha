import React, { useState, useMemo, useEffect } from "react";
import { Idol, PoojaItem, CartItem, Order, AppState, AuthUser } from "../types";
import { Search, SlidersHorizontal, ShoppingCart, ShoppingBag, Truck, MapPin, X, Plus, Minus, Check, ArrowRight, ShieldCheck, Sparkles, RefreshCw, Layers, Phone, LayoutGrid, Calendar, HelpCircle, Eye, AlertCircle, Home, User, Settings, Volume2, VolumeX } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface StorefrontProps {
  appState: AppState;
  onPlaceOrder: (cart: CartItem) => Promise<Order | null>;
  deviceId: string;
  isSimulatorView?: boolean;
  searchQuery: string;
  setSearchQuery: (val: string) => void;
  selectedStyle: string;
  setSelectedStyle: (val: string) => void;
  priceRange: number;
  setPriceRange: (val: number) => void;
  selectedQuality: string;
  setSelectedQuality: (val: string) => void;
  showFilters: boolean;
  setShowFilters: (val: boolean) => void;
  currentUser: AuthUser | null;
  onRequestAuth?: () => void;
  isOmPlaying?: boolean;
  onToggleOm?: () => void;
}

export default function Storefront({
  appState,
  onPlaceOrder,
  deviceId,
  isSimulatorView = false,
  searchQuery,
  setSearchQuery,
  selectedStyle,
  setSelectedStyle,
  priceRange,
  setPriceRange,
  selectedQuality,
  setSelectedQuality,
  showFilters,
  setShowFilters,
  currentUser,
  onRequestAuth,
  isOmPlaying,
  onToggleOm
}: StorefrontProps) {
  // Catalog View Toggles & Column options
  const [activeTab, setActiveTab] = useState<"catalog" | "3d-animation">("catalog");
  const [gridCols, setGridCols] = useState<number>(2);
  const [showQuickSettings, setShowQuickSettings] = useState(false);
  const [showQuickProfile, setShowQuickProfile] = useState(false);

  // User private orders state
  const [userOrders, setUserOrders] = useState<Order[]>([]);
  const [showBookingsModal, setShowBookingsModal] = useState(false);
  const [isFetchingUserOrders, setIsFetchingUserOrders] = useState(false);

  // Cart Management
  const [cart, setCart] = useState<CartItem | null>(null);
  const [showPoojaUpsell, setShowPoojaUpsell] = useState(false);
  const [showCartDrawer, setShowCartDrawer] = useState(false);

  // Modal Views
  const [activeDetailsIdol, setActiveDetailsIdol] = useState<Idol | null>(null);
  const [detailsImageIndex, setDetailsImageIndex] = useState(0);
  const [bookingSuccessOrder, setBookingSuccessOrder] = useState<Order | null>(null);

  // Out of stock recommendations
  const [outOfStockSelection, setOutOfStockSelection] = useState<Idol | null>(null);
  const [simulatedRecommendation, setSimulatedRecommendation] = useState<Idol | null>(null);

  // Checkout Form Details fallback to logged in membership
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [checkoutStep, setCheckoutStep] = useState<"details" | "payment">("details");
  const [isSubmittingBooking, setIsSubmittingBooking] = useState(false);

  // Prefill user details if logged in
  useEffect(() => {
    if (currentUser) {
      setCustomerName(currentUser.displayName || "");
      setCustomerPhone(currentUser.email || currentUser.phone || "");
    }
  }, [currentUser]);

  // Read private devotee orders on access
  const handleFetchUserOrders = async () => {
    if (!currentUser) return;
    try {
      setIsFetchingUserOrders(true);
      const url = `/api/user/orders?email=${encodeURIComponent(currentUser.email || "")}&phone=${encodeURIComponent(currentUser.phone || "")}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setUserOrders(data);
      }
    } catch (e) {
      console.error("Failed fetching user reservations:", e);
    } finally {
      setIsFetchingUserOrders(false);
    }
  };

  useEffect(() => {
    if (showBookingsModal) {
      handleFetchUserOrders();
    }
  }, [showBookingsModal, currentUser, appState.orders]);

  // Unique Styles List from available data
  const styleOptions = useMemo(() => {
    const list = new Set<string>();
    appState.idols.forEach(i => list.add(i.style));
    return ["All", ...Array.from(list)];
  }, [appState.idols]);

  // Filtered Idols output
  const filteredIdols = useMemo(() => {
    return appState.idols.filter(idol => {
      const matchesSearch = idol.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            idol.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            idol.style.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStyle = selectedStyle === "All" || idol.style === selectedStyle;
      const matchesPrice = (idol.price - (idol.price * (idol.discount / 100))) <= priceRange;
      const matchesQuality = selectedQuality === "All" || idol.quality.toLowerCase().includes(selectedQuality.toLowerCase());
      return matchesSearch && matchesStyle && matchesPrice && matchesQuality;
    });
  }, [appState.idols, searchQuery, selectedStyle, priceRange, selectedQuality]);

  // Reset Filters to defaults
  const handleResetFilters = () => {
    setSearchQuery("");
    setSelectedStyle("All");
    setPriceRange(15000);
    setSelectedQuality("All");
  };

  // Add Ganesha to Cart logic
  const handleAddToCart = (idol: Idol) => {
    if (idol.stock <= 0) {
      // Out of Stock! Trigger custom recommendation modal
      setOutOfStockSelection(idol);
      // Let's suggest a random similar Ganesha that currently has stock
      const inStockAlternatives = appState.idols.filter(
        (i) => i.id !== idol.id && i.stock > 0
      );
      if (inStockAlternatives.length > 0) {
        const randomIndex = Math.floor(Math.random() * inStockAlternatives.length);
        setSimulatedRecommendation(inStockAlternatives[randomIndex]);
      } else {
        setSimulatedRecommendation(null);
      }
      return;
    }

    // Set initial cart item
    setCart({
      idol,
      poojaItems: appState.poojaItems.map(item => ({ item, quantity: 0 })),
      deliveryType: "pickup", // default to self service pickup
      paymentType: "advance"  // default to advance book
    });

    // Close any Ganesha details dialog being read
    setActiveDetailsIdol(null);

    // Open pooja essentials drawer suggestion
    setShowPoojaUpsell(true);
  };

  // Upsell list adjustments
  const handleModifyPooja = (itemId: string, diff: number) => {
    if (!cart) return;
    setCart(prev => {
      if (!prev) return null;
      return {
        ...prev,
        poojaItems: prev.poojaItems.map(p => {
          if (p.item.id === itemId) {
            const nextQty = Math.max(0, p.quantity + diff);
            return { ...p, quantity: nextQty };
          }
          return p;
        })
      };
    });
  };

  // Skip or confirm pooja extras
  const handleCompletePoojaChoice = () => {
    setShowPoojaUpsell(false);
    setShowCartDrawer(true);
  };

  // Calculations
  const calculations = useMemo(() => {
    if (!cart) return { ganeshaBase: 0, ganeshaDiscounted: 0, poojaAmount: 0, deliveryCharge: 0, subtotal: 0, initialPaymentNeeded: 0, remainingPaymentNeeded: 0 };
    
    // Ganesha Calculations
    const originalGanesha = cart.idol.price;
    const discountedGanesha = originalGanesha - (originalGanesha * (cart.idol.discount / 100));
    
    // Delivery Charges
    const delivery = cart.deliveryType === "delivery" ? cart.idol.deliveryCharge : 0;
    
    // Pooja Items Calculations
    const poojaTotal = cart.poojaItems.reduce((acc, current) => {
      return acc + (current.item.price * current.quantity);
    }, 0);

    const grandTotal = discountedGanesha + delivery + poojaTotal;

    // Minimum Booking Advance (Flat ₹1000 or total price, whichever is lower)
    const advanceCap = Math.min(1000, grandTotal);

    // Dynamic invoice
    const finalPaymentType = cart.deliveryType === "delivery" ? "full" : cart.paymentType;
    const initialPay = finalPaymentType === "full" ? grandTotal : advanceCap;
    const remainingPay = grandTotal - initialPay;

    return {
      ganeshaBase: originalGanesha,
      ganeshaDiscounted: discountedGanesha,
      poojaAmount: poojaTotal,
      deliveryCharge: delivery,
      subtotal: grandTotal,
      initialPaymentNeeded: initialPay,
      remainingPaymentNeeded: remainingPay
    };
  }, [cart]);

  // Mock UPI Payment trigger
  const handleMakeMockBooking = async () => {
    if (!cart) return;
    if (!customerName || !customerPhone) {
      alert("Please specify customer name and active mobile number to book.");
      return;
    }
    if (cart.deliveryType === "delivery" && !deliveryAddress) {
      alert("Home delivery requires a valid street address destination.");
      return;
    }

    setIsSubmittingBooking(true);

    // Build order object payload
    const selectedPoojaEssentials = cart.poojaItems
      .filter(p => p.quantity > 0)
      .map(p => ({
        id: p.item.id,
        quantity: p.quantity
      }));

    // Post order in real-time
    const orderOutcome = await onPlaceOrder({
      ...cart,
      customerName,
      customerPhone,
      deliveryAddress
    });

    setIsSubmittingBooking(false);

    if (orderOutcome) {
      setBookingSuccessOrder(orderOutcome);
      setCart(null);
      // Reset checkout states
      setCustomerName("");
      setCustomerPhone("");
      setDeliveryAddress("");
      setCheckoutStep("details");
      setShowCartDrawer(false);
    }
  };

  return (
    <div className={`h-full flex flex-col relative font-sans ${isSimulatorView ? "text-[11px] bg-black/20 p-2" : "text-white"}`}>
      {/* SECTOR A: DYNAMIC TOOLBAR & VIEW COMPREHENSION */}
      {/* MOBILE DEVICE COMPACT PERSISTENT SINGLE ROW TOOLBAR (Only shown on <md screens) */}
      <div className="flex md:hidden items-center justify-between w-full border-b border-white/5 pb-2.5 mb-3 gap-2 select-none">
        {/* Compact Toggle fully aligned to the left */}
        <div className="bg-white/5 p-0.5 rounded-lg border border-white/10 flex gap-0.5 font-sans font-bold backdrop-blur-md">
          <button
            onClick={() => {
              setActiveTab("catalog");
              if (gridCols > 2) setGridCols(2);
            }}
            className={`px-2.5 py-1 text-[10px] rounded-md cursor-pointer transition-all flex items-center gap-1 ${
              activeTab === "catalog"
                ? "bg-orange-500 text-white font-extrabold shadow-sm"
                : "text-white/70 hover:text-white"
            }`}
          >
            <LayoutGrid className="w-3 h-3" />
            <span>Catalog</span>
          </button>
          
          <button
            onClick={() => {
              setActiveTab("3d-animation");
              if (gridCols > 2) setGridCols(2);
            }}
            className={`px-2.5 py-1 text-[10px] rounded-md cursor-pointer transition-all flex items-center gap-1 ${
              activeTab === "3d-animation"
                ? "bg-orange-500 text-white font-extrabold shadow-sm animate-pulse"
                : "text-white/70 hover:text-white"
            }`}
          >
            <Sparkles className="w-3 h-3 text-current" />
            <span>3D</span>
          </button>
        </div>

        {/* Compact Grid with grid size set as 1 and 2 only, fully aligned to the right */}
        <div className="flex items-center gap-1 bg-black/40 border border-white/10 p-0.5 rounded-lg text-[9px] font-mono select-none">
          <span className="text-white/55 px-1 font-bold">Col:</span>
          {[1, 2].map((num) => (
            <button
              key={num}
              onClick={() => setGridCols(num)}
              className={`px-2 py-0.5 rounded font-bold cursor-pointer transition-all text-[10px] ${
                gridCols === num 
                  ? "bg-orange-500 text-white shadow-xs" 
                  : "text-white/80 hover:bg-white/5"
              }`}
            >
              {num}
            </button>
          ))}
        </div>
      </div>

      {/* WEB VIEW STANDARD ALIGNED TOOLBAR (Only shown on >=md screens) */}
      <div className="hidden md:flex flex-row items-center justify-between gap-3 w-full border-b border-white/5 pb-3.5 mb-4">
        {/* LEFT ALIGNED: Active Tab Toggle */}
        <div className="flex items-center justify-between w-full sm:w-auto gap-2">
          <div className="bg-white/5 p-1 rounded-xl border border-white/10 flex gap-0.5 select-none text-[10.5px] font-sans font-bold backdrop-blur-md">
            <button
              onClick={() => {
                setActiveTab("catalog");
                setGridCols(3); // recover standard grid view on tab toggle in webview
              }}
              className={`px-3 py-1.5 rounded-lg cursor-pointer transition-all flex items-center gap-1.5 ${
                activeTab === "catalog"
                  ? "bg-orange-500 text-white font-extrabold shadow-md"
                  : "text-white/70 hover:text-white"
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Catalog Gallery</span>
            </button>
            
            <button
              onClick={() => {
                setActiveTab("3d-animation");
                setGridCols(3); // recover standard grid view on tab toggle in webview
              }}
              className={`px-3 py-1.5 rounded-lg cursor-pointer transition-all flex items-center gap-1.5 ${
                activeTab === "3d-animation"
                  ? "bg-orange-500 text-white font-extrabold shadow-md animate-pulse"
                  : "text-white/70 hover:text-white"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-current" />
              <span>3D Anime Tab</span>
            </button>
          </div>
        </div>

        {/* RIGHT ALIGNED: Grid Control Selector with (3, 4, 6) options for standard web views */}
        <div className="flex items-center justify-between sm:justify-end gap-3 w-full sm:w-auto">
          <div className="flex items-center gap-1.5 bg-black/40 border border-white/10 p-1 rounded-xl text-[10.5px] font-mono select-none font-bold">
            <span className="text-white/55 ml-1.5 mr-1 text-[11px]">Grid Cols:</span>
            {[3, 4, 6].map((num) => (
              <button
                key={num}
                onClick={() => setGridCols(num)}
                className={`px-2.5 py-1 rounded-lg font-bold cursor-pointer transition-all text-[11px] ${
                  gridCols === num 
                    ? "bg-orange-500 text-white shadow-sm" 
                    : "text-white/80 hover:bg-white/5"
                }`}
                title={`${num} Columns Grid`}
              >
                {num}
              </button>
            ))}
          </div>

          {/* Secure Bookings button specifically for logged in devotee */}
          {currentUser && (
            <button
              onClick={() => setShowBookingsModal(true)}
              className="bg-yellow-400/15 border border-yellow-300/35 hover:bg-yellow-400/25 text-yellow-300 font-bold text-xs py-2 px-3 rounded-xl cursor-pointer flex items-center gap-1 transition-all"
            >
              <Calendar className="w-3.5 h-3.5 text-yellow-400 stroke-[2]" />
              <span className="hidden md:inline">Reservations</span>
            </button>
          )}
        </div>
      </div>

      {/* FILTER RECAP DROP AREA */}
      {(showFilters || selectedStyle !== "All" || selectedQuality !== "All") && (
        <div className="p-3.5 md:p-4 mb-5 bg-slate-900/90 border border-white/15 rounded-2xl space-y-3 font-mono animate-fadeIn backdrop-blur-md shadow-2xl relative">
          <button
            onClick={() => setShowFilters(false)}
            className="absolute top-3 right-3 text-white/50 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
          
          {/* Material Filters Row */}
          <div>
            <span className="text-[10px] text-white/70 uppercase block mb-1.5 font-bold">Divine Craft Material</span>
            <div className="flex flex-wrap gap-1.5">
              {styleOptions.map((style) => (
                <button
                  key={style}
                  onClick={() => setSelectedStyle(style)}
                  className={`px-2.5 py-1 text-[10px] font-bold rounded-lg cursor-pointer transition-all ${
                    selectedStyle === style
                      ? "bg-yellow-400 text-orange-950"
                      : "bg-white/5 hover:bg-white/10 text-white/90 border border-white/10"
                  }`}
                >
                  {style}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Price budget */}
            <div>
              <div className="flex items-center justify-between text-[10px] text-white/70 uppercase mb-1 font-bold">
                <span>Maximum Booking Budget</span>
                <span className="text-yellow-300 font-bold">₹{priceRange} or less</span>
              </div>
              <input
                type="range"
                min="3000"
                max="15000"
                step="500"
                value={priceRange}
                onChange={(e) => setPriceRange(parseInt(e.target.value))}
                className="w-full accent-yellow-400 h-1 cursor-pointer bg-white/20 rounded-lg outline-none"
              />
            </div>

            {/* Quality grade list */}
            <div>
              <span className="text-[10px] text-white/70 uppercase block mb-1 font-bold">Purity Grade Style</span>
              <div className="flex gap-2">
                <select
                  value={selectedQuality}
                  onChange={(e) => setSelectedQuality(e.target.value)}
                  className="w-full bg-slate-950 border border-white/20 text-white text-[10px] p-2 rounded-lg outline-none cursor-pointer"
                >
                  <option value="All" className="bg-slate-950 text-white">All Quality Grades</option>
                  <option value="Vedic Pure" className="bg-slate-950 text-white">Vedic Pure Shadu</option>
                  <option value="Premium" className="bg-slate-950 text-white">Premium Artistry</option>
                  <option value="Deluxe" className="bg-slate-950 text-white">Standard Deluxe</option>
                </select>

                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="text-pink-300 hover:text-pink-200 font-bold cursor-pointer text-[10px] underline bg-white/5 border border-white/15 px-2.5 py-1.5 rounded-lg transition-all"
                >
                  Reset
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTOR B: TAB RENDER ROUTING */}
      <div className="flex-1 overflow-y-auto pb-28 md:pb-6">
        {filteredIdols.length === 0 ? (
          <div className="p-8 text-center bg-zinc-900/30 border border-zinc-800 rounded-3xl flex flex-col items-center justify-center">
            <ShoppingBag className="w-8 h-8 text-zinc-650 mb-2" />
            <p className="text-zinc-400 font-semibold text-xs">No matching idols available</p>
            <p className="text-[10px] text-zinc-500 mt-1">
              Adjust your filters or query params to discover Ganesha idols.
            </p>
            <button
              onClick={handleResetFilters}
              className="mt-3.5 bg-zinc-800 hover:bg-zinc-700 font-semibold rounded-lg text-[10px] py-1.5 px-3 flex items-center gap-1 text-amber-400 cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : activeTab === "3d-animation" ? (
          /* TAB 2: INTERACTIVE IMMERSIVE PHOTO GALLERY GRID WITH MINIMIZED MOBILE FONTS */
          <div className={`grid gap-2 sm:gap-4 ${
            gridCols === 1
              ? "grid-cols-1"
              : gridCols === 2
                ? "grid-cols-2"
                : gridCols === 6
                  ? "grid-cols-2 xs:grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6"
                  : gridCols === 4
                    ? "grid-cols-2 xs:grid-cols-3 md:grid-cols-4"
                    : "grid-cols-2 sm:grid-cols-3"
          }`}>
            {filteredIdols.map((idol) => {
              const discountedPrice = idol.price - (idol.price * (idol.discount / 100));
              const isOutOfStock = idol.stock <= 0;

              return (
                <motion.div
                  key={`3d-${idol.id}`}
                  whileHover={{ 
                    scale: 1.025,
                  }}
                  className={`bg-slate-900 border border-white/10 overflow-hidden rounded-xl relative shadow-lg transition-all aspect-[3/4] flex flex-col justify-end group ${
                    isOutOfStock 
                      ? "border-pink-900/20 opacity-80" 
                      : "border-yellow-500/20 hover:border-orange-500 hover:shadow-orange-500/10 animate-[fadeIn_0.5s_ease-out]"
                  }`}
                  onClick={() => setActiveDetailsIdol(idol)}
                >
                  {/* Photo Frame Container - edge-to-edge with shadow gradient overlay */}
                  <div className="absolute inset-0 w-full h-full bg-black">
                    <img
                      src={idol.imgUrl}
                      alt={idol.name}
                      className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/45 to-transparent z-10" />
                  </div>

                  {/* Badges in margins - minimized to never overlap */}
                  <div className="absolute top-1.5 left-1.5 right-1.5 z-20 flex justify-between items-start gap-1">
                    {idol.discount > 0 ? (
                      <span className="bg-orange-600 text-white font-bold text-[7.5px] px-1.5 py-0.5 rounded shadow-md leading-none">
                        -{idol.discount}%
                      </span>
                    ) : (
                      <span />
                    )}

                    {isOutOfStock ? (
                      <span className="bg-pink-600 text-white text-[7px] font-bold uppercase px-1.5 py-0.5 rounded shadow-md leading-none">
                        Booked
                      </span>
                    ) : idol.stock <= 2 ? (
                      <span className="bg-orange-500 text-white text-[7px] font-bold px-1.5 py-0.5 rounded shadow-md leading-none animate-pulse">
                        {idol.stock} Left!
                      </span>
                    ) : (
                      <span className="bg-green-500 text-white text-[6.5px] font-bold px-1 py-0.5 rounded shadow-md leading-none">
                        {idol.height}
                      </span>
                    )}
                  </div>

                  {/* Empty space pusher */}
                  <div className="flex-1" />

                  {/* Fully overlay bottom text/booking bar with watermark styled transparency */}
                  <div 
                    className="p-1.5 md:p-2.5 relative z-20 bg-black/60 backdrop-blur-md border-t border-white/5 space-y-1 opacity-40 group-hover:opacity-100 transition-opacity duration-300 pointer-events-auto"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center justify-between gap-1 leading-none">
                      <div className="flex flex-col min-w-0">
                        <h3 className="font-sans font-black text-white text-[9.5px] md:text-[11px] truncate leading-none mb-0.5">
                          {idol.name}
                        </h3>
                        <div className="flex items-baseline gap-1 mt-0.5">
                          <span className="text-yellow-300 font-extrabold text-[10px] md:text-[12px] font-mono leading-none">₹{discountedPrice}</span>
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAddToCart(idol);
                        }}
                        className={`text-[8.5px] md:text-[10px] uppercase tracking-wider font-extrabold px-2 py-1 rounded transition-all cursor-pointer leading-none ${
                          isOutOfStock 
                            ? "bg-white/5 border border-white/10 text-white/30" 
                            : "bg-orange-500 text-white hover:bg-orange-600 active:scale-95 shadow"
                        }`}
                      >
                        {isOutOfStock ? "Filled" : "Book"}
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        ) : (
          /* TAB 1: STUNNING RESPONSIVE DYNAMIC GRID VIEW SENSITIVE TO CHOICES */
          <div className={`grid gap-2.5 sm:gap-4 ${
            gridCols === 1
              ? "grid-cols-1"
              : gridCols === 2
                ? "grid-cols-2"
                : gridCols === 6
                  ? "grid-cols-2 xs:grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6"
                  : gridCols === 4
                    ? "grid-cols-2 xs:grid-cols-3 md:grid-cols-4"
                    : "grid-cols-2 sm:grid-cols-3"
          }`}>
            {filteredIdols.map((idol) => {
              const discountedPrice = idol.price - (idol.price * (idol.discount / 100));
              const isOutOfStock = idol.stock <= 0;
              
              return (
                <div
                  key={idol.id}
                  className={`bg-white/10 backdrop-blur-md border overflow-hidden rounded-xl transition-all duration-300 relative flex flex-col justify-between ${
                    isOutOfStock 
                      ? "border-pink-950/20 shadow-none grayscale-[20%] opacity-85" 
                      : "border-white/10 hover:border-yellow-400/45 hover:shadow-2xl hover:shadow-yellow-400/10 group"
                  }`}
                >
                  {/* Idol photo container */}
                  <div
                    onClick={() => setActiveDetailsIdol(idol)}
                    className="aspect-square bg-slate-950 flex items-center justify-center relative overflow-hidden cursor-pointer w-full group-hover:opacity-95 transition-all p-1.5"
                  >
                    <img
                      src={idol.imgUrl}
                      alt={idol.name}
                      className="max-h-full max-w-full object-contain filter drop-shadow-[0_6px_20px_rgba(0,0,0,0.6)] transition-transform duration-500 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Hot Deal Ribbon tag - minimal to avoid overlap */}
                    {idol.discount > 0 && (
                      <div className="absolute top-1.5 left-1.5 bg-pink-600 shadow shadow-black/40 text-white text-[7.5px] md:text-[9.5px] font-black px-1.5 py-0.5 rounded font-mono leading-none z-10">
                        {idol.discount}% OFF
                      </div>
                    )}

                    {/* Quality Badges */}
                    <div className="absolute bottom-1.5 left-1.5 flex flex-wrap gap-1 z-10 pointer-events-none">
                      <span className="bg-black/60 backdrop-blur text-white text-[7px] md:text-[8px] font-mono px-1 py-0.5 rounded">
                        {idol.height}
                      </span>
                    </div>

                    {/* Booking Stock level status */}
                    <div className="absolute top-1.5 right-1.5 z-10 pointer-events-none">
                      {isOutOfStock ? (
                        <span className="bg-pink-600 text-white text-[7px] md:text-[8.5px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded font-mono animate-pulse inline-block leading-none">
                          SOLD OUT
                        </span>
                      ) : idol.stock <= 2 ? (
                        <span className="bg-orange-500 text-white text-[7px] md:text-[8.5px] font-bold px-1.5 py-0.5 rounded font-mono inline-block leading-none animate-pulse">
                          {idol.stock} Left!
                        </span>
                      ) : (
                        <span className="bg-green-500/90 backdrop-blur text-white text-[7px] md:text-[8px] font-bold px-1 py-0.5 rounded font-mono inline-block leading-none">
                          In Stock
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Body textual content */}
                  <div className="p-2 md:p-3.5 flex-1 flex flex-col justify-between space-y-2">
                    <div>
                      <h3 className="font-bold text-white group-hover:text-yellow-300 transition-colors text-[10.5px] sm:text-xs md:text-sm truncate">
                        {idol.name}
                      </h3>
                      {/* Description - removed on mobile, visible on desktop / tablet standard screens */}
                      <p className="text-[10px] text-white/50 mt-1 line-clamp-2 leading-relaxed hidden sm:block">
                        {idol.description}
                      </p>
                    </div>

                    <div className="border-t border-white/10 pt-2 flex items-center justify-between gap-1">
                      {/* Price labels */}
                      <div className="flex flex-col">
                        <span className="text-[7.5px] md:text-[9px] text-white/40 uppercase font-black tracking-wider leading-none">Booking Price</span>
                        <div className="flex items-baseline gap-1 mt-0.5 font-mono leading-none">
                          {idol.discount > 0 ? (
                            <>
                              <span className="text-yellow-300 font-bold text-xs md:text-sm">₹{discountedPrice}</span>
                              <span className="text-white/45 text-[8px] md:text-[9.5px] line-through">₹{idol.price}</span>
                            </>
                          ) : (
                            <span className="text-yellow-300 font-bold text-xs md:text-sm">₹{idol.price}</span>
                          )}
                        </div>
                      </div>

                      {/* Quick Action Book Button: says Book only in mobile view */}
                      <button
                        onClick={() => handleAddToCart(idol)}
                        className={`font-black cursor-pointer transition-all rounded-lg py-1.5 px-2.5 text-[9px] md:text-xs flex items-center gap-1 border leading-none ${
                          isOutOfStock
                            ? "bg-white/5 border-white/10 text-pink-300 hover:bg-white/10"
                            : "bg-yellow-400 hover:bg-yellow-300 border-yellow-300 text-orange-950 font-extrabold hover:scale-[1.02]"
                        }`}
                      >
                        {isOutOfStock ? (
                          <>
                            <span className="block md:hidden">Filled</span>
                            <span className="hidden md:block">Show Alternatives</span>
                          </>
                        ) : (
                          <>
                            <span className="block md:hidden">Book</span>
                            <span className="hidden md:block">Book Ganesha</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* FIXED NAV - Floating Cart Indicator */}
      {cart && (
        <div className="fixed bottom-4 inset-x-0 w-full flex justify-center px-4 z-[90]">
          <button
            onClick={() => setShowCartDrawer(true)}
            className="bg-yellow-400 hover:bg-yellow-300 border border-white/20 text-orange-950 font-black py-3 px-6 rounded-full shadow-2xl flex items-center justify-between gap-6 max-w-[320px] w-full transform hover:scale-[1.02] transition-all cursor-pointer font-sans"
          >
            <div className="flex items-center gap-2">
              <div className="relative">
                <ShoppingCart className="w-5 h-5 text-orange-950" />
                <span className="absolute -top-2.5 -right-2 bg-pink-600 text-white font-bold text-[9px] w-4.5 h-4.5 rounded-full flex items-center justify-center border border-white leading-none">
                  1
                </span>
              </div>
              <span className="text-xs uppercase font-black tracking-wider">Review Booking Item</span>
            </div>
            <ArrowRight className="w-4 h-4 text-orange-950 animate-pulse" />
          </button>
        </div>
      )}

      {/* MODAL 1: Out of Stock Recommendation Trigger */}
      {outOfStockSelection && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[990] flex items-center justify-center p-4">
          <div className="bg-purple-950/70 border border-white/20 rounded-2xl p-5 w-full max-w-[420px] shadow-2xl relative backdrop-blur-md text-white animate-fadeIn">
            <button
              onClick={() => {
                setOutOfStockSelection(null);
                setSimulatedRecommendation(null);
              }}
              className="absolute top-4 right-4 text-white/70 hover:text-white bg-white/10 p-1.5 rounded-full cursor-pointer hover:bg-white/20 border border-white/10"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center">
              <span className="w-12 h-12 rounded-full bg-pink-600/20 text-pink-300 border border-pink-500/30 flex items-center justify-center mx-auto mb-3">
                <ShieldCheck className="w-6 h-6 stroke-[1.5]" />
              </span>
              <h3 className="text-md font-black text-white font-sans">
                Model: &ldquo;{outOfStockSelection.name}&rdquo; is Fully Booked!
              </h3>
              <p className="text-xs text-white/80 mt-1 font-mono">
                The specified craft inventory is currently booked by other custom patrons.
              </p>
            </div>

            {/* Simulated Recommendation option */}
            {simulatedRecommendation ? (
              <div className="mt-5 border-t border-white/10 pt-4">
                <span className="text-[10px] text-yellow-300 uppercase tracking-wider font-extrabold block mb-3 font-mono text-center flex items-center justify-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-yellow-300 animate-spin" />
                  Divinely Suggested Alternative IDOL
                </span>

                <div className="p-3 bg-black/40 border border-white/15 rounded-xl flex gap-3">
                  <img
                    src={simulatedRecommendation.imgUrl}
                    className="w-16 h-16 rounded object-cover bg-black flex-shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <h4 className="font-extrabold text-white text-xs truncate">
                        {simulatedRecommendation.name}
                      </h4>
                      <p className="text-[9px] text-white/70 font-mono mt-0.5">
                        {simulatedRecommendation.style} • {simulatedRecommendation.height}
                      </p>
                    </div>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-yellow-300 font-extrabold font-mono text-xs">
                        ₹{simulatedRecommendation.price - (simulatedRecommendation.price * (simulatedRecommendation.discount / 100))}
                      </span>
                      <button
                        onClick={() => {
                          const idolToSelect = simulatedRecommendation;
                          setOutOfStockSelection(null);
                          setSimulatedRecommendation(null);
                          handleAddToCart(idolToSelect);
                        }}
                        className="bg-yellow-400 hover:bg-yellow-300 border-yellow-300 text-orange-950 font-bold py-1 px-2.5 rounded text-[10px] cursor-pointer"
                      >
                        Book This Instead
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-white/50 text-[10px] mt-4 font-mono text-center">
                Currently, all options of Ganesha idols are closed for booking. Check with helpdesk.
              </p>
            )}
          </div>
        </div>
      )}

      {/* MODAL 2: Pooja Upsell recommendation modal triggers prior, when added */}
      {showPoojaUpsell && cart && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[990] flex items-center justify-center p-4">
          <div className="bg-purple-950/70 border border-white/20 rounded-2xl w-full max-w-[440px] shadow-2xl overflow-hidden font-sans backdrop-blur-md text-white animate-fadeIn">
            
            <div className="p-4 bg-gradient-to-r from-yellow-500/20 to-orange-500/10 border-b border-white/10 text-center relative">
              <span className="absolute top-2.5 right-2.5 text-white/70 hover:text-white bg-white/10 p-1 rounded-full cursor-pointer hover:bg-white/20" onClick={() => setShowPoojaUpsell(false)}>
                <X className="w-4 h-4" />
              </span>
              <Sparkles className="w-8 h-8 text-yellow-300 mx-auto mb-1 animate-pulse" />
              <h3 className="font-extrabold text-white text-base">Make Ganesha Welcome Complete!</h3>
              <p className="text-[11px] text-white/80 mt-0.5">
                We suggest adding these sacred essentials before finishing booking.
              </p>
            </div>

            {/* List of pooja products */}
            <div className="p-4 space-y-3 max-h-[300px] overflow-y-auto">
              {cart.poojaItems.map((p) => (
                <div
                  key={p.item.id}
                  className={`p-2.5 rounded-xl border flex items-center justify-between transition-all duration-300 ${
                    p.quantity > 0
                      ? "bg-yellow-400/10 border-yellow-300/40"
                      : "bg-black/35 border-white/10 hover:bg-black/45"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl flex-shrink-0 bg-black/40 w-10 h-10 rounded-full flex items-center justify-center border border-white/10">
                      {p.item.icon}
                    </span>
                    <div className="min-w-0">
                      <h4 className="font-extrabold text-white text-xs truncate leading-snug">{p.item.name}</h4>
                      <p className="text-[9px] text-white/70 max-w-[200px] leading-tight mt-0.5">{p.item.description}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 flex-shrink-0 font-mono text-[11px]">
                    <span className="font-extrabold text-yellow-300">+₹{p.item.price}</span>
                    <div className="flex items-center bg-white/15 rounded border border-white/20 p-0.5">
                      <button
                        onClick={() => handleModifyPooja(p.item.id, -1)}
                        className="px-1 text-white/70 hover:text-white font-bold"
                      >
                        -
                      </button>
                      <span className="px-1 text-white min-w-[14px] text-center font-bold">
                        {p.quantity}
                      </span>
                      <button
                        onClick={() => handleModifyPooja(p.item.id, 1)}
                        className="px-1 text-white/70 hover:text-white font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {/* Confirm choices panel */}
            <div className="p-4 border-t border-white/15 bg-black/40 flex gap-2">
              <button
                onClick={handleCompletePoojaChoice}
                className="flex-1 bg-yellow-400 hover:bg-yellow-300 border border-yellow-300 text-orange-950 font-black p-2.5 rounded-xl text-xs cursor-pointer flex items-center justify-center gap-1 font-sans shadow-md"
              >
                <span>Add & View Cart Invoice</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleCompletePoojaChoice}
                className="px-4 text-white/70 hover:text-white font-extrabold text-xs"
              >
                Skip Extras
              </button>
            </div>

          </div>
        </div>
      )}
             {/* DRAWER 3: Direct Express Cart Drawer */}
      {showCartDrawer && (
        <div className="fixed top-0 bottom-[62px] md:bottom-0 left-0 right-0 z-[975] md:z-[990] bg-black/85 backdrop-blur-md flex justify-end">
          <div className="bg-slate-900 border-l border-white/10 h-full w-full max-w-[420px] shadow-2xl flex flex-col font-sans text-white animate-slideInRight">
            
            {/* Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-black/20">
              <h3 className="font-extrabold text-white text-base flex items-center gap-1.5 font-sans">
                <ShoppingCart className="w-5 h-5 text-yellow-300" />
                Ganesha Booking Invoice
              </h3>
              <button
                onClick={() => setShowCartDrawer(false)}
                className="text-white/70 hover:text-white p-1.5 rounded-full cursor-pointer bg-white/10 border border-white/10 hover:bg-white/20 transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Scroll content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              
              {!cart ? (
                <div className="py-24 text-center flex flex-col items-center justify-center gap-4">
                  <span className="text-5xl animate-bounce">🌺</span>
                  <h4 className="text-sm font-black text-yellow-400">Your Booking Cart is Empty</h4>
                  <p className="text-[10px] text-white/60 max-w-xs leading-relaxed font-mono px-4">
                    Please select a Ganesha idol from our divine catalog first to initialize its reservation booking ticket.
                  </p>
                  <button
                    onClick={() => setShowCartDrawer(false)}
                    className="mt-2 bg-yellow-400 hover:bg-yellow-350 text-orange-950 px-5 py-2.5 rounded-xl text-xs font-black cursor-pointer shadow-md border border-yellow-300 transition-all font-sans"
                  >
                    Explore Ganesha Catalog
                  </button>
                </div>
              ) : (
                <>
                  {/* Checkout Steps Switch */}
                  <div className="flex bg-black/35 border border-white/15 p-1 rounded-lg gap-1.5 font-mono text-[10px] uppercase font-black text-center">
                    <span className={`flex-1 py-1 rounded-md ${checkoutStep === 'details' ? 'bg-yellow-400 text-orange-950' : 'text-white/50'}`}>
                      1. Contact Details
                    </span>
                    <span className={`flex-1 py-1 rounded-md ${checkoutStep === 'payment' ? 'bg-yellow-400 text-orange-950' : 'text-white/50'}`}>
                      2. UPI QR Payment
                    </span>
                  </div>

                  {checkoutStep === "details" ? (
                    /* STEP 1: Details and Delivery Preferences selection */
                    <div className="space-y-4 font-sans text-xs">
                      {/* Select Ganesha review */}
                      <div className="p-3 bg-black/35 border border-white/10 rounded-xl flex items-start gap-3">
                        <img
                          src={cart.idol.imgUrl}
                          className="w-14 h-14 rounded object-cover bg-black"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0 text-xs">
                          <h4 className="font-extrabold text-white truncate">{cart.idol.name}</h4>
                          <p className="text-[10px] text-white/70 font-mono mt-0.5">{cart.idol.style} • {cart.idol.height}</p>
                          <p className="text-yellow-300 font-black font-mono text-xs mt-1.5">
                            ₹{calculations.ganeshaDiscounted}
                            {cart.idol.discount > 0 && (
                              <span className="text-white/50 font-normal line-through text-[10px] ml-1.5">
                                ₹{cart.idol.price}
                              </span>
                            )}
                          </p>
                        </div>
                      </div>

                      {/* List of accessories added details */}
                      {cart.poojaItems.some((pi) => pi.quantity > 0) && (
                        <div className="p-3 bg-black/25 border border-white/10 rounded-xl font-mono text-[10px] text-white/70 space-y-1">
                          <span className="text-[9px] uppercase font-bold text-white/50">Pooja Accessories:</span>
                          {cart.poojaItems
                            .filter((p) => p.quantity > 0)
                            .map((p, idx) => (
                              <div key={idx} className="flex justify-between">
                                <span>{p.item.icon} {p.item.name} (x{p.quantity})</span>
                                <span className="text-white">₹{p.item.price * p.quantity}</span>
                              </div>
                          ))}
                        </div>
                      )}

                      {/* Delivery type selectors */}
                      <div className="space-y-2">
                        <h4 className="font-extrabold text-white/95">Choose Obtaining Method:</h4>
                        <div className="grid grid-cols-2 gap-2.5 font-mono">
                          {/* Self Service Pickup */}
                          <button
                            onClick={() => {
                              setCart((prev) => prev ? { ...prev, deliveryType: "pickup" } : null);
                            }}
                            className={`p-2.5 rounded-xl border text-center flex flex-col items-center justify-center gap-1.5 transition-all text-[11px] cursor-pointer ${
                              cart.deliveryType === "pickup"
                                ? "bg-yellow-400/10 border-yellow-300 text-yellow-300 font-extrabold"
                                : "bg-black/35 border-white/10 text-white/80 hover:bg-black/45"
                            }`}
                          >
                            <MapPin className="w-5 h-5 text-yellow-300" />
                            <span>Self Pickup (Akurdi Hub)</span>
                          </button>

                          {/* Home Delivery */}
                          <button
                            onClick={() => {
                              if (!cart.idol.deliveryProvided) {
                                alert("This specific heavy or delicate Ganesha does not support home delivery due to safety regulations. Self pickup only.");
                                return;
                              }
                              setCart((prev) => prev ? { ...prev, deliveryType: "delivery" } : null);
                            }}
                            className={`p-2.5 rounded-xl border text-center flex flex-col items-center justify-center gap-1.5 transition-all text-[11px] cursor-pointer ${
                              cart.deliveryType === "delivery"
                                ? "bg-yellow-400/10 border-yellow-300 text-yellow-300 font-extrabold"
                                : "bg-black/35 border-white/10 text-white/40 hover:bg-black/45 hover:text-white/65"
                            }`}
                          >
                            <Truck className="w-5 h-5 text-yellow-300" />
                            <span>Home Delivery (+₹{cart.idol.deliveryCharge})</span>
                          </button>
                        </div>
                      </div>

                      {/* Form Contact details */}
                      <div className="space-y-2 pt-2 border-t border-white/10">
                        <h4 className="font-extrabold text-white/80">Recipient Ganesha Bookings details:</h4>
                        
                        <div className="space-y-2">
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <label className="text-white/60 font-sans block text-[11px]">Your Full Name</label>
                              {currentUser ? (
                                <span className="text-[9px] text-green-400 font-bold bg-green-500/10 px-1.5 py-0.5 rounded">✓ Autofilled</span>
                              ) : (
                                <span className="text-[9px] text-yellow-500/80 font-bold">⚠️ Guest Mode (register for automatic logs)</span>
                              )}
                            </div>
                            <input
                              type="text"
                              required
                              value={customerName}
                              onChange={(e) => setCustomerName(e.target.value)}
                              placeholder="e.g. Prathamesh G."
                              className="w-full bg-black/40 border border-white/15 p-2.5 rounded-lg text-white text-xs outline-none focus:ring-2 focus:ring-yellow-400 transition-all placeholder-white/50"
                            />
                          </div>

                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <label className="text-white/60 block text-[11px]">Mobile Contact Phone Number</label>
                              {currentUser ? (
                                <span className="text-[9px] text-green-400 font-bold bg-green-500/10 px-1.5 py-0.5 rounded">✓ Autofilled</span>
                              ) : (
                                <span className="text-[10px] text-pink-400 font-mono">Required</span>
                              )}
                            </div>
                            <input
                              type="text"
                              required
                              value={customerPhone}
                              onChange={(e) => setCustomerPhone(e.target.value)}
                              placeholder="10-digit mobile number"
                              className="w-full bg-black/40 border border-white/15 p-2.5 rounded-lg text-white text-xs outline-none focus:ring-2 focus:ring-yellow-400 transition-all font-mono placeholder-white/50"
                            />
                          </div>

                          {cart.deliveryType === "delivery" && (
                            <div>
                              <label className="text-white/60 block mb-1">Full Delivery Address Destination</label>
                              <textarea
                                required
                                value={deliveryAddress}
                                onChange={(e) => setDeliveryAddress(e.target.value)}
                                placeholder="Street, society name, pincode"
                                rows={2}
                                className="w-full bg-black/40 border border-white/15 p-2.5 rounded-lg text-white text-xs outline-none focus:ring-2 focus:ring-yellow-400 transition-all placeholder-white/50"
                              />
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Payments Mode Choice */}
                      {cart.deliveryType === "pickup" ? (
                        <div className="bg-black/35 p-3 rounded-xl border border-white/10 space-y-2">
                          <span className="text-[10px] text-white/60 uppercase font-bold tracking-wider block font-mono">
                            Pickup Payment Choice:
                          </span>
                          <div className="grid grid-cols-2 gap-2 font-mono text-[10px]">
                            {/* Token Advance Payment */}
                            <button
                              onClick={() => setCart(prev => prev ? { ...prev, paymentType: "advance" } : null)}
                              className={`p-2 rounded-lg border text-center font-bold cursor-pointer transition-all ${
                                cart.paymentType === "advance"
                                  ? "bg-yellow-400 text-orange-950 border-white/20"
                                  : "bg-white/10 text-white/80 border-white/10 hover:bg-white/15"
                              }`}
                            >
                              💸 Secure Advance Pay (Only ₹{calculations.initialPaymentNeeded})
                            </button>

                            {/* Full Payment */}
                            <button
                              onClick={() => setCart(prev => prev ? { ...prev, paymentType: "full" } : null)}
                              className={`p-2 rounded-lg border text-center font-bold cursor-pointer transition-all ${
                                cart.paymentType === "full"
                                  ? "bg-yellow-400 text-orange-950 border-white/20"
                                  : "bg-white/10 text-white/80 border-white/10 hover:bg-white/15"
                              }`}
                            >
                              🏦 Prepay Full Amount (₹{calculations.subtotal})
                            </button>
                          </div>
                          <p className="text-[10px] text-white/60 leading-normal font-mono pt-1">
                            {cart.paymentType === "advance" 
                              ? `Pay ₹${calculations.initialPaymentNeeded} now. Pay final remaining ₹${calculations.remainingPaymentNeeded} during pickup.` 
                              : "Prepay full amount now to bypass payment desk during Akurdi physical pickup."
                            }
                          </p>
                        </div>
                      ) : (
                        /* Delivery Mode pays always Full amount upfront */
                        <div className="bg-purple-950/40 p-2.5 rounded-xl border border-purple-500/20 font-mono text-[9px] text-purple-200">
                          🚚 Home Delivery demands full prepayment (₹{calculations.subtotal}) of the total Ganesha invoice to deploy active safe dispatch drivers to your location.
                        </div>
                      )}
                    </div>
                  ) : (() => {
                    const upiId = appState.settings?.adminUpiId || "prathmg1991@okaxis";
                    const upiName = appState.settings?.adminUpiName || "Vighnaharta Utsav Akurdi Hub";
                    const upiUrl = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(upiName)}&am=${calculations.initialPaymentNeeded}&tn=GaneshaBookingReservation&cu=INR`;
                    const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(upiUrl)}`;
                    
                    return (
                      /* STEP 2: Secure QR payments presentation screen */
                      <div className="space-y-4 flex flex-col items-center p-3 text-center">
                        
                        {/* Financial Total Display */}
                        <div className="w-full bg-black/35 p-3 rounded-xl border border-white/10 font-mono">
                          <span className="text-[10px] text-white/60 uppercase font-black tracking-wider">You are Booking via UPI Code:</span>
                          <h2 className="text-xl font-black text-yellow-300 mt-1">₹{calculations.initialPaymentNeeded}</h2>
                          <p className="text-[9px] text-white/70 mt-1">
                            {cart.deliveryType === "pickup" && cart.paymentType === "advance" 
                              ? `Booking reservation ticket. Balance ₹${calculations.remainingPaymentNeeded} pay while physical pickup.` 
                              : "Upfront full payment including pooja accessories."
                            }
                          </p>
                        </div>

                        {/* QR Code Presentation Box */}
                        <div className="border-4 border-yellow-300/30 bg-white p-2.5 rounded-2xl w-[170px] h-[170px] relative shadow-lg shadow-black flex items-center justify-center">
                          <img 
                            src={qrImageUrl} 
                            alt="UPI QR Code" 
                            className="w-[145px] h-[145px] rounded-lg object-contain"
                          />
                          {/* Tiny Center Ganesha Icon */}
                          <div className="absolute inset-auto bg-amber-500 border-2 border-white p-0.5 rounded-full w-8 h-8 flex items-center justify-center text-xs shadow-md">
                            🕉️
                          </div>
                        </div>

                        {/* Recipient UPI ID text to fulfill configuration transparency */}
                        <div className="bg-black/35 w-full border border-white/10 rounded-xl py-2 px-3 font-mono text-[9px] text-left space-y-0.5">
                          <p className="text-white/60">UPI Recipient Address details:</p>
                          <p className="text-white font-extrabold truncate">🎯 {upiName}</p>
                          <p className="text-yellow-300 font-bold font-sans">🔑 {upiId}</p>
                        </div>

                        <p className="text-[10px] text-white/80 max-w-[240px] leading-relaxed">
                          Double-tap or scan this secure gateway UPI code using your mobile banking apps (GPay, PhonePe, Paytm, BHIM) to credit Akurdi divine booking counter.
                        </p>

                        <div className="w-full border-t border-white/10 pt-3 flex flex-col gap-2.5">
                          <button
                            onClick={handleMakeMockBooking}
                            disabled={isSubmittingBooking}
                            className="bg-green-500 hover:bg-green-400 text-white font-extrabold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-1.5 animate-pulse cursor-pointer shadow-lg w-full font-sans"
                          >
                            <ShieldCheck className="w-4 h-4" />
                            <span>{isSubmittingBooking ? "Securing Booking..." : "I Scanned & Paid Securely"}</span>
                          </button>
                          
                          <button
                            onClick={() => setCheckoutStep("details")}
                            className="text-white/60 hover:text-white font-bold text-[10px] underline"
                          >
                            Go back to details edit
                          </button>
                        </div>
                      </div>
                    );
                  })()}

                  {/* Cart footer invoice totals */}
                  {checkoutStep === "details" && (
                    <div className="p-4 bg-black/40 border-t border-white/10 space-y-3 font-mono text-[11px] text-white/70">
                      <div className="flex justify-between">
                        <span>Ganesha Idol Base:</span>
                        <span>₹{calculations.ganeshaBase}</span>
                      </div>
                      {cart.idol.discount > 0 && (
                        <div className="flex justify-between text-pink-300">
                          <span>Active Festive Code ({cart.idol.discount}% OFF):</span>
                          <span>-₹{calculations.ganeshaBase - calculations.ganeshaDiscounted}</span>
                        </div>
                      )}
                      {cart.deliveryType === "delivery" && (
                        <div className="flex justify-between text-yellow-300">
                          <span>Home Shipping:</span>
                          <span>+₹{calculations.deliveryCharge}</span>
                        </div>
                      )}
                      {calculations.poojaAmount > 0 && (
                        <div className="flex justify-between text-purple-300">
                          <span>Pooja Items Added:</span>
                          <span>+₹{calculations.poojaAmount}</span>
                        </div>
                      )}
                      <div className="flex justify-between border-t border-white/15 pt-2 font-extrabold text-white text-xs">
                        <span>Gross Total Invoice:</span>
                        <span className="text-yellow-300 text-sm">₹{calculations.subtotal}</span>
                      </div>

                      {/* Subsidized deposit pay check */}
                      {cart.deliveryType === "pickup" && cart.paymentType === "advance" && (
                        <div className="p-2 bg-yellow-400/10 rounded-lg text-yellow-300 text-[10px] leading-relaxed flex items-center justify-between border border-yellow-300/30">
                          <span>Deposit Due Upfront:</span>
                          <span className="font-bold">₹{calculations.initialPaymentNeeded}</span>
                        </div>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          if (!customerName || !customerPhone) {
                            alert("Please add required fill inputs! Both Full Name and Mobile contact details are mandatory.");
                            return;
                          }
                          if (cart.deliveryType === "delivery" && !deliveryAddress) {
                            alert("Home delivery requires a valid street address destination.");
                            return;
                          }
                          setCheckoutStep("payment");
                        }}
                        className="w-full bg-yellow-400 hover:bg-yellow-300 border border-yellow-300 text-orange-950 font-black py-3 rounded-xl text-xs flex justify-center items-center gap-1 cursor-pointer font-sans shadow-lg"
                      >
                        <span>Advance to UPI Payment</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>

          </div>
        </div>
      )}

      {/* MODAL 4: Full detailed catalog viewer + Interactive rotate animations */}
      {activeDetailsIdol && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[990] flex items-center justify-center p-4">
          <div className="bg-purple-950/70 border border-white/20 rounded-2xl w-full max-w-[480px] shadow-2xl overflow-hidden font-sans relative max-h-[90vh] flex flex-col backdrop-blur-md text-white animate-fadeIn">
            <button
              onClick={() => {
                setActiveDetailsIdol(null);
                setDetailsImageIndex(0);
              }}
              className="absolute top-4 right-4 z-50 text-white/70 hover:text-white bg-white/10 p-1.5 rounded-full cursor-pointer hover:bg-white/20 border border-white/10"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Carousel display with multi-image support */}
            <div className="aspect-[4/3] bg-zinc-950 relative overflow-hidden flex-shrink-0 animate-fadeIn">
              <img
                src={
                  activeDetailsIdol.secondaryImages && activeDetailsIdol.secondaryImages.length > 0
                    ? activeDetailsIdol.secondaryImages[detailsImageIndex]
                    : activeDetailsIdol.imgUrl
                }
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />

              {/* Dot Indicators */}
              {activeDetailsIdol.secondaryImages && activeDetailsIdol.secondaryImages.length > 1 && (
                <div className="absolute bottom-3 inset-x-0 flex justify-center gap-1.5 z-40">
                  {activeDetailsIdol.secondaryImages.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setDetailsImageIndex(idx)}
                      className={`w-2.5 h-2.5 rounded-full transition-all ${detailsImageIndex === idx ? 'w-4 bg-yellow-400' : 'bg-white/40'}`}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Details panel body scroll */}
            <div className="p-4 overflow-y-auto space-y-3 flex-1 text-xs text-white/90">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-md font-extrabold text-white font-sans tracking-tight">{activeDetailsIdol.name}</h2>
                  <p className="text-[10px] text-white/60 font-mono mt-0.5">Style: <strong className="text-yellow-300">{activeDetailsIdol.style}</strong></p>
                </div>
                <div className="text-right font-mono text-[13px]">
                  <span className="text-yellow-300 font-extrabold block">
                    ₹{activeDetailsIdol.price - (activeDetailsIdol.price * (activeDetailsIdol.discount / 100))}
                  </span>
                  {activeDetailsIdol.discount > 0 && (
                    <span className="text-white/40 line-through text-[10px]">₹{activeDetailsIdol.price}</span>
                  )}
                </div>
              </div>

              <p className="text-[11px] leading-relaxed text-white/80 bg-black/40 p-2.5 rounded-xl border border-white/10">
                {activeDetailsIdol.description}
              </p>

              {/* Technical features tags */}
              <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-white/75">
                <div className="p-2 bg-black/30 border border-white/10 rounded">
                  <span className="text-white/50 block">Quality Scale</span>
                  <strong className="text-white">{activeDetailsIdol.quality}</strong>
                </div>
                <div className="p-2 bg-black/30 border border-white/10 rounded">
                  <span className="text-white/50 block">Color finish</span>
                  <strong className="text-white">{activeDetailsIdol.color}</strong>
                </div>
                <div className="p-2 bg-black/30 border border-white/10 rounded">
                  <span className="text-white/50 block">Height frame</span>
                  <strong className="text-white">{activeDetailsIdol.height}</strong>
                </div>
                <div className="p-2 bg-black/30 border border-white/10 rounded">
                  <span className="text-white/50 block">Stock status</span>
                  <strong className={activeDetailsIdol.stock > 0 ? "text-green-300" : "text-pink-300"}>
                    {activeDetailsIdol.stock > 0 ? `Available (${activeDetailsIdol.stock} units)` : "FULLY BOOKED"}
                  </strong>
                </div>
              </div>
            </div>

            {/* Bottom action bar */}
            <div className="p-4 bg-black/40 border-t border-white/10 flex gap-2 animate-fadeIn">
              <button
                onClick={() => handleAddToCart(activeDetailsIdol)}
                className={`flex-1 font-black p-3 rounded-xl border text-xs cursor-pointer text-center font-sans shadow-md ${
                  activeDetailsIdol.stock <= 0
                    ? "bg-white/5 border-white/10 text-pink-300"
                    : "bg-yellow-400 border-yellow-300 text-orange-950 hover:bg-yellow-300"
                }`}
              >
                {activeDetailsIdol.stock <= 0 ? "Inspect Alternate Models" : "Reserve & Book Ganesha Idol"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 5: Booking Success confirmation Screen */}
      {bookingSuccessOrder && (() => {
        const adminPhone = appState.settings?.adminWhatsappNumber || "919876543210";
        const adminName = appState.settings?.adminUpiName || "Vighnaharta Utsav Admin";
        
        const customerMsg = `*🌺 Blessed Ganpati Booking Confirmed! 🌺*\nDear *${bookingSuccessOrder.customerName}*, your sacred booking for Lord Ganesha is successful!\n\n*INVOICE DETAILS:*\n📍 Order Ref: ${bookingSuccessOrder.id}\n🪔 Ganesha: ${bookingSuccessOrder.idolName}\n📦 Dispatch: ${bookingSuccessOrder.deliveryType === 'delivery' ? 'Home Delivery' : 'Self-Pickup Akurdi Hub'}\n💰 Gross Invoice: ₹${bookingSuccessOrder.totalAmount}\n🌸 Booking Advance Paid: ₹${bookingSuccessOrder.paymentAmount}\n🚩 Pending Balance: ₹${bookingSuccessOrder.remainingAmount}\n\nThank you for embracing eco-friendly pure divine energy!\n_May Lord Ganesha dissolve all obstacles and bless your home!_ ॐ`;
        const adminMsg = `*🚨 NEW GANESHA UTSAV BOOKING! 🚨*\nJai Ganesh! A new devotee has booked/enquired an idol from the inventory!\n\n👤 Devotee: *${bookingSuccessOrder.customerName}* (${bookingSuccessOrder.customerPhone})\n🚩 Deity: *${bookingSuccessOrder.idolName}*\n📦 Mode: *${bookingSuccessOrder.deliveryType.toUpperCase()}*\n💰 Gross Invoice: ₹${bookingSuccessOrder.totalAmount}\n💳 Advance Paid: ₹${bookingSuccessOrder.paymentAmount}\n📱 Status: Active reservation (Stock updated automatically)`;

        const customerWaUrl = `https://api.whatsapp.com/send?phone=${bookingSuccessOrder.customerPhone.replace(/[^0-9]/g, "")}&text=${encodeURIComponent(customerMsg)}`;
        const adminWaUrl = `https://api.whatsapp.com/send?phone=${adminPhone.replace(/[^0-9]/g, "")}&text=${encodeURIComponent(adminMsg)}`;

        return (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[999] flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-purple-950/90 border-2 border-yellow-300/40 rounded-3xl p-5 w-full max-w-[460px] text-center shadow-2xl relative my-8 animate-fadeIn font-sans backdrop-blur-md text-white max-h-[92vh] flex flex-col overflow-hidden">
              <div className="overflow-y-auto flex-1 pr-1 space-y-4">
                <span className="text-4xl block animate-bounce">🌺🕉️🌺</span>
                
                <div className="w-12 h-12 rounded-full bg-green-500/20 text-green-300 border border-green-500/30 flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6 stroke-[2.5]" />
                </div>

                <div>
                  <h2 className="text-lg font-black text-yellow-350">Jai Dev Dev Ganesha!</h2>
                  <h3 className="text-sm font-bold text-white mt-0.5">Booking Confirmed & Live Synced</h3>
                  <p className="text-[10px] text-white/70 font-mono mt-0.5">
                    Order Reference ID: <strong className="text-yellow-300">{bookingSuccessOrder.id}</strong>
                  </p>
                </div>

                {/* Booking receipt summary */}
                <div className="bg-black/45 p-3.5 rounded-2xl border border-white/10 text-[11px] font-mono text-white/85 space-y-1 text-left">
                  <p>👤 Devotee: <strong className="text-white">{bookingSuccessOrder.customerName}</strong></p>
                  <p>📱 Mobile Phone: <strong className="text-white">{bookingSuccessOrder.customerPhone}</strong></p>
                  <p>🪔 Blessed Ganesha: <strong className="text-white">{bookingSuccessOrder.idolName}</strong></p>
                  <p>📦 Obtaining Mode: <strong className="text-white uppercase">{bookingSuccessOrder.deliveryType}</strong></p>
                  <div className="border-t border-white/10 my-1.5 pt-1.5 flex justify-between font-bold">
                    <span className="text-green-305">Amount Paid:</span>
                    <span className="text-green-300 text-xs font-extrabold">₹{bookingSuccessOrder.paymentAmount}</span>
                  </div>
                  {bookingSuccessOrder.remainingAmount > 0 && (
                    <div className="flex justify-between font-bold text-pink-300">
                      <span>Balance Due at Pickup:</span>
                      <span>₹{bookingSuccessOrder.remainingAmount}</span>
                    </div>
                  )}
                </div>

                {/* Automated WhatsApp Billing Dispatched Status Alert */}
                <div className="bg-yellow-400/10 border border-yellow-300/20 rounded-2xl p-3 text-left">
                  <div className="flex items-center gap-2 mb-2 text-yellow-350 font-bold text-[11px] uppercase tracking-wide">
                    <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                    <span>WhatsApp Gateway Dispatched</span>
                  </div>
                  <p className="text-[10px] text-white/80 leading-relaxed leading-normal">
                    The Vighnaharta backend automatically triggered custom WhatsApp bills to both numbers:
                  </p>
                  
                  {/* Customer WhatsApp Details */}
                  <div className="mt-2.5 p-2 bg-black/35 rounded-xl border border-white/5 space-y-1">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-white/60">👤 Customer ({bookingSuccessOrder.customerPhone})</span>
                      <span className="text-[9px] bg-green-500/20 text-green-300 px-1.5 py-0.5 rounded uppercase font-bold">Auto Dispatched</span>
                    </div>
                    <p className="text-[9px] text-white/70 italic line-clamp-2 leading-tight">
                      {customerMsg}
                    </p>
                    <a 
                      href={customerWaUrl} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="inline-flex items-center gap-1 text-[9px] text-green-400 hover:underline mt-1 font-bold"
                    >
                      <Phone className="w-2.5 h-2.5" />
                      Verify/Trigger Chat directly on Devotee Web WhatsApp
                    </a>
                  </div>

                  {/* Admin WhatsApp Details */}
                  <div className="mt-2 p-2 bg-black/35 rounded-xl border border-white/5 space-y-1">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-white/60">👑 Admin ({adminPhone})</span>
                      <span className="text-[9px] bg-green-500/20 text-green-300 px-1.5 py-0.5 rounded uppercase font-bold">Notification Sent</span>
                    </div>
                    <p className="text-[9px] text-white/70 italic line-clamp-2 leading-tight">
                      {adminMsg}
                    </p>
                    <a 
                      href={adminWaUrl} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="inline-flex items-center gap-1 text-[9px] text-green-400 hover:underline mt-1 font-bold"
                    >
                      <Phone className="w-2.5 h-2.5" />
                      Verify/Trigger notification on Admin Web WhatsApp
                    </a>
                  </div>
                </div>

                <p className="text-[10px] text-white/50 leading-relaxed font-mono">
                  Lord Ganesha&apos;s live database decreased stock counts in real-time across all connected client browser tabs.
                </p>
              </div>

              <div className="pt-3 border-t border-white/10">
                <button
                  onClick={() => setBookingSuccessOrder(null)}
                  className="w-full bg-yellow-400 hover:bg-yellow-300 border border-yellow-300 text-orange-950 font-black py-2.5 rounded-xl text-xs cursor-pointer font-sans shadow-lg uppercase tracking-wide"
                >
                  Continue Worship & Book More
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* MODAL 6: CUSTOM DEVOTIONAL BOOKINGS HUB DIALOG */}
      {showBookingsModal && (
        <div className="fixed top-0 bottom-[62px] md:bottom-0 left-0 right-0 z-[975] md:z-[990] bg-black/80 backdrop-blur-md flex items-center justify-center p-3 md:p-4">
          <div className="bg-slate-900 border border-white/15 rounded-3xl w-full max-w-[640px] shadow-2xl overflow-hidden font-sans relative max-h-[85vh] flex flex-col backdrop-blur-md text-white animate-fadeIn">
            
            <header className="px-6 py-4 border-b border-white/10 flex justify-between items-center bg-black/20">
              <div className="flex items-center gap-2">
                <span className="text-xl">🌺</span>
                <div>
                  <h3 className="font-sans font-black text-yellow-400 text-sm">Devotee Bookings Hub</h3>
                  <p className="text-[9px] font-mono text-white/50 tracking-wider">Your personal secure inventory bookings</p>
                </div>
              </div>
              
              <button
                onClick={() => setShowBookingsModal(false)}
                className="text-white/60 hover:text-white bg-white/5 hover:bg-white/15 p-2 rounded-xl cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </header>

            <div className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
              {isFetchingUserOrders ? (
                <div className="py-12 text-center flex flex-col items-center justify-center gap-2">
                  <RefreshCw className="w-8 h-8 text-yellow-400 animate-spin" />
                  <p className="text-white/60 font-mono text-[10px]">Calling Akurdi Temple Database...</p>
                </div>
              ) : userOrders.length === 0 ? (
                <div className="py-12 text-center bg-black/20 border border-white/5 rounded-2xl flex flex-col items-center justify-center">
                  <span className="text-3xl mb-2">🌸</span>
                  <p className="text-white/80 font-bold">No active reservations found</p>
                  <p className="text-[10px] text-white/55 mt-1 max-w-xs mx-auto leading-relaxed">
                    Make your first booking selection today and look forward to celebrating Ganesha Chaturthi with joy & auspiciousness!
                  </p>
                </div>
              ) : (
                <div className="space-y-4 font-mono">
                  {userOrders.map((order) => {
                    const originalGanesha = order.idolSnapshot ? order.idolSnapshot.price : 6500;
                    const discount = order.idolSnapshot ? order.idolSnapshot.discount : 0;
                    const discountedGanesha = originalGanesha - (originalGanesha * (discount / 100));
                    const totalPooja = order.poojaSnapshot 
                      ? order.poojaSnapshot.reduce((acc, current) => acc + (current.price * current.quantity), 0)
                      : 0;
                    const grandTotal = discountedGanesha + totalPooja + (order.deliveryType === "delivery" ? 450 : 0);

                    return (
                      <div key={order.id} className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3 shadow-md relative">
                        {/* Status Label badge */}
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5">
                          <div>
                            <span className="text-white/55 text-[8px] uppercase block">Booking ID</span>
                            <strong className="text-yellow-300 font-bold text-[10px]">{order.id}</strong>
                          </div>
                          <div className="text-right">
                            <span className="text-white/55 text-[8px] uppercase block">Status</span>
                            <span className={`inline-block py-0.5 px-2 rounded-full text-[9px] font-bold ${
                              order.status === "completed" 
                                ? "bg-green-500/20 text-green-300" 
                                : order.status === "cancelled" 
                                  ? "bg-red-500/20 text-red-300" 
                                  : "bg-yellow-400/20 text-yellow-300"
                            }`}>
                              ● {order.status.toUpperCase()}
                            </span>
                          </div>
                        </div>

                        {/* Order breakdown summary */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[10px] pt-1">
                          <div>
                            <span className="text-white/40 block">Divine Ganesha Selection:</span>
                            <span className="text-white font-extrabold text-[11px]">{order.idolSnapshot?.name || "Lord Ganesha Idol"}</span>
                            <span className="text-white/60 block mt-0.5">Type: {order.idolSnapshot?.style} • Height: {order.idolSnapshot?.height}</span>
                          </div>
                          <div className="sm:text-right">
                            <span className="text-white/40 block">Total Amount Ordered:</span>
                            <strong className="text-yellow-400 font-extrabold text-sm font-sans">₹{grandTotal}</strong>
                            <span className="text-white/50 block text-[9px]">
                              {order.paymentType === "advance" ? "Advance Deposit Paid" : "Full Payment Settled"}
                            </span>
                          </div>
                        </div>

                        {/* Automated WhatsApp timeline auditing tracker */}
                        <div className="pt-2 border-t border-white/5 space-y-2">
                          <span className="text-[8px] font-sans text-yellow-400 uppercase tracking-widest font-bold block">
                            📞 Divine Dispatch WhatsApp Logs
                          </span>
                          
                          <div className="space-y-1 bg-black/40 p-2.5 rounded-xl border border-white/5 text-[9px] text-white/80">
                            <div className="flex justify-between items-center text-white/50">
                              <span>Customer Info Line ({order.customerPhone})</span>
                              <span className="bg-green-500/20 text-green-400 py-0.5 px-1.5 rounded uppercase font-bold text-[8px]">WhatsApp Sent</span>
                            </div>
                            <p className="italic leading-normal mt-1 text-white/95">
                              &ldquo;Shree Ganeshay Namah! Your booking for #{order.id} {order.idolSnapshot?.name} is success at Akurdi depot! Advance deposit ₹1000 received. Jai Dev!&rdquo;
                            </p>
                          </div>
                          
                          <div className="space-y-1 bg-black/40 p-2.5 rounded-xl border border-white/5 text-[9px] text-white/80">
                            <div className="flex justify-between items-center text-white/50">
                              <span>Temple Admin Direct Line (+919876543210)</span>
                              <span className="bg-green-500/20 text-green-400 py-0.5 px-1.5 rounded uppercase font-bold text-[8px]">WhatsApp Alert</span>
                            </div>
                            <p className="italic leading-normal mt-1 text-white/95">
                              &ldquo;ALERT: Devotee {order.customerName} has successfully booked #{order.id} ({order.idolSnapshot?.name}) with ₹1000 advance. Lock Ganesha stock ID {order.idolSnapshot?.id}!&rdquo;
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <footer className="p-4 border-t border-white/10 bg-black/20 text-center">
              <button
                onClick={() => setShowBookingsModal(false)}
                className="bg-yellow-400 hover:bg-yellow-350 active:scale-95 transition-all text-orange-950 font-black px-6 py-2 rounded-xl text-xs cursor-pointer shadow"
              >
                Done
              </button>
            </footer>

          </div>
        </div>
      )}

      {/* QUICK SETTINGS NATIVE BOTTOM SHEET */}
      <AnimatePresence>
        {showQuickSettings && (
          <div className="fixed top-0 bottom-[62px] md:bottom-0 left-0 right-0 bg-black/60 backdrop-blur-sm z-[975] flex items-end justify-center">
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="bg-slate-900 border-t border-white/10 rounded-t-3xl w-full max-w-[440px] p-5 pb-10 md:pb-24 shadow-2xl space-y-4 text-white font-sans text-left z-50 mb-0"
            >
              <div className="flex justify-between items-center border-b border-white/10 pb-3">
                <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                  <Settings className="w-5 h-5 text-yellow-300" />
                  <span>Devotee Preferences</span>
                </h3>
                <button
                  onClick={() => setShowQuickSettings(false)}
                  className="bg-white/10 hover:bg-white/20 p-1.5 rounded-full text-white/80 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Grid Catalog Display columns option */}
              <div className="space-y-2">
                <label className="text-[11px] uppercase font-mono tracking-wider text-white/50 block font-bold">
                  📁 Catalog Grid Layout Options
                </label>
                <div className="grid grid-cols-3 gap-2 text-[10px]">
                  {[
                    { val: 2, label: "1-Col List 📱" },
                    { val: 3, label: "2-Col Grid 📖" },
                    { val: 4, label: "3-Col Dense 💻" }
                  ].map((item) => (
                    <button
                      key={item.val}
                      onClick={() => setGridCols(item.val as 2 | 3 | 4)}
                      className={`p-2 rounded-xl border font-bold cursor-pointer transition-all text-center leading-tight ${
                        gridCols === item.val
                          ? "bg-yellow-400 border-yellow-300 text-orange-950 shadow-md"
                          : "bg-black/35 border-white/10 hover:bg-white/5 text-white/80"
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Om sound controller option */}
              {onToggleOm && (
                <div className="flex items-center justify-between bg-black/40 p-3 rounded-xl border border-white/5">
                  <div className="space-y-0.5 text-left">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      OM sound: {isOmPlaying ? "ON" : "OFF"}
                    </span>
                    <p className="text-[10px] text-white/60 leading-tight">
                      Adjust background meditation vibrations
                    </p>
                  </div>
                  <button
                    onClick={onToggleOm}
                    className={`p-2 px-4 rounded-xl border font-black text-[11px] uppercase cursor-pointer transition-all ${
                      isOmPlaying
                        ? "bg-yellow-400 border-yellow-300 text-orange-950"
                        : "bg-white/5 border-white/10 text-white"
                    }`}
                  >
                    Toggle Sound
                  </button>
                </div>
              )}

              {/* Quality / Soil filter preference */}
              <div className="space-y-2">
                <span className="text-[11px] uppercase font-mono tracking-wider text-white/50 block font-bold">
                  🌱 Soil & Eco Preference
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {["All", "Shadu Clay", "Red Soil", "Marble Dust"].map((q) => (
                    <button
                      key={q}
                      onClick={() => setSelectedQuality(q)}
                      className={`px-3 py-1.5 rounded-full border text-[10px] font-bold cursor-pointer transition-all ${
                        selectedQuality === q
                          ? "bg-yellow-400 border-yellow-300 text-orange-950"
                          : "bg-black/25 border-white/10 text-white/80 hover:bg-white/5"
                      }`}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>

              {/* ADMIN LOGIN STEPS & DEEPLINK SECURE ROUTE */}
              <div className="bg-amber-400/5 border border-amber-400/20 p-3.5 rounded-2xl space-y-2 mt-1">
                <div className="flex items-center gap-1.5 text-amber-300 font-extrabold text-[11px] uppercase tracking-wider font-mono">
                  <span>🛡️ Administrative Cloud Portal</span>
                </div>
                <p className="text-[10.5px] text-white/80 leading-relaxed">
                  To view live sales, manage Ganesha inventory stocks, or print physical hand-over tickets at Akurdi depot:
                </p>
                <div className="space-y-1 pl-1 text-[9.5px] font-mono text-zinc-300 leading-normal">
                  <div className="flex gap-1.5">
                    <span className="text-yellow-400">Step 1:</span>
                    <span>Navigate to the Admin Panel by clicking the dashboard link below.</span>
                  </div>
                  <div className="flex gap-1.5">
                    <span className="text-yellow-400">Step 2:</span>
                    <span>The secure system auto-detects cloud permissions to lock/unlock Ganesha stock levels.</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowQuickSettings(false);
                    window.location.search = "view=admin";
                  }}
                  className="w-full bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-350 hover:to-orange-450 text-orange-950 font-black p-2.5 rounded-xl text-xs cursor-pointer shadow-md border border-yellow-300/35 text-center flex items-center justify-center gap-1.5 transition-all active:scale-95 mt-1"
                >
                  <span>Launch Admin Control Center ↗</span>
                </button>
              </div>

              {/* Reset to defaults helper button */}
              <button
                onClick={() => {
                  handleResetFilters();
                  setShowQuickSettings(false);
                }}
                className="w-full bg-white/5 hover:bg-white/10 text-white text-[11px] font-bold py-2 rounded-xl transition-all block border border-white/10 text-center"
              >
                Clear Filters & Reset Defaults
              </button>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* QUICK PROFILE NATIVE BOTTOM SHEET */}
      <AnimatePresence>
        {showQuickProfile && (
          <div className="fixed top-0 bottom-[62px] md:bottom-0 left-0 right-0 bg-black/60 backdrop-blur-sm z-[975] flex items-end justify-center">
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="bg-slate-900 border-t border-white/10 rounded-t-3xl w-full max-w-[440px] p-5 pb-10 md:pb-24 shadow-2xl space-y-4 text-white font-sans text-left z-50 mb-0"
            >
              <div className="flex justify-between items-center border-b border-white/10 pb-3">
                <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                  <User className="w-5 h-5 text-yellow-300" />
                  <span>Devotee Hub Profile</span>
                </h3>
                <button
                  onClick={() => setShowQuickProfile(false)}
                  className="bg-white/10 hover:bg-white/20 p-1.5 rounded-full text-white/80 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {currentUser ? (
                <div className="space-y-4">
                  {/* Logged in dev details */}
                  <div className="bg-yellow-400/5 aspect-auto p-4 rounded-2xl border border-yellow-300/25 flex items-center gap-3.5 shadow-inner">
                    <span className="text-3xl bg-yellow-400/20 w-14 h-14 rounded-full flex items-center justify-center border border-yellow-300/30">
                      🌺
                    </span>
                    <div className="text-left">
                      <h4 className="text-sm font-black text-white">{currentUser.displayName || "Devoted Devotee"}</h4>
                      <p className="text-[11px] text-white/60 font-mono mt-0.5">{currentUser.email || currentUser.phone || "Verified Guest Customer"}</p>
                      <span className="inline-block bg-green-500/20 text-green-300 border border-green-500/35 text-[8px] font-black tracking-wider uppercase mt-1 px-1.5 py-0.5 rounded">
                        Connected Sync Active
                      </span>
                    </div>
                  </div>

                  {/* Devotee information metrics */}
                  <div className="grid grid-cols-2 gap-2 text-center text-xs">
                    <div className="bg-black/30 p-2.5 rounded-xl border border-white/5">
                      <span className="text-white/45 text-[8px] uppercase block tracking-wider font-mono">My Bookings</span>
                      <span className="text-base font-black text-yellow-300 mt-1 block">
                        {userOrders.length || 0}
                      </span>
                    </div>
                    <div className="bg-black/30 p-2.5 rounded-xl border border-white/5">
                      <span className="text-white/45 text-[8px] uppercase block tracking-wider font-mono">Location</span>
                      <span className="text-[10px] font-black text-orange-400 mt-1 block truncate">
                        Akurdi Depot
                      </span>
                    </div>
                  </div>

                  {/* Orders shortcut trigger */}
                  <button
                    onClick={() => {
                      setShowBookingsModal(true);
                      setShowQuickProfile(false);
                    }}
                    className="w-full bg-yellow-400 hover:bg-yellow-350 active:scale-95 text-orange-950 font-black p-3 rounded-xl text-xs cursor-pointer shadow-md border border-yellow-300/40 flex items-center justify-center gap-1.5"
                  >
                    <span>View Reservation History Tickets</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  {/* Devotee Info disclaimer text */}
                  <div className="text-[9px] text-white/40 leading-relaxed text-center italic font-mono pt-1">
                    Your bookings are persisted in Akurdi Cloud Vault. Present booking ID for quick entry pickup.
                  </div>
                </div>
              ) : (
                <div className="text-center py-4 space-y-4">
                  <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto border border-white/10">
                    <User className="w-8 h-8 text-white/40" />
                  </div>
                  
                  <div className="space-y-1 px-2 text-center">
                    <h4 className="text-sm font-extrabold text-white">Join Devotee Booking Vault</h4>
                    <p className="text-[10px] text-white/60 leading-relaxed max-w-xs mx-auto">
                      Sign in using Google SSO or OTP to keep your Lord Ganesha bookings safely saved and track delivery schedules automatically.
                    </p>
                  </div>

                  {/* Trigger login block */}
                  <button
                    onClick={() => {
                      setShowQuickProfile(false);
                      if (onRequestAuth) {
                        onRequestAuth();
                      }
                    }}
                    className="bg-yellow-400 hover:bg-yellow-350 text-orange-950 font-black px-6 py-2.5 rounded-xl text-xs cursor-pointer shadow-md inline-flex items-center gap-1.5"
                  >
                    <span>Log In / Register Devotee</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <div className="text-[9px] text-white/40 text-center font-mono">
                    Fast • Secure • No Password Required
                  </div>
                </div>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* NATIVE BOTTOM NAVIGATION MENU BAR */}
      {(() => {
        const isHomeActive = activeTab === "catalog" && !showQuickSettings && !showQuickProfile && !showCartDrawer && !showBookingsModal;
        const isCartActive = showCartDrawer;
        const isOrdersActive = showBookingsModal;
        const isSettingsActive = showQuickSettings;
        const isProfileActive = showQuickProfile;

        return (
          <div className="fixed bottom-0 left-0 right-0 z-[980] md:hidden bg-slate-900/95 border-t border-white/10 backdrop-blur-md px-4 py-3 flex items-center justify-around text-white/90 select-none pb-safe shadow-[0_-10px_35px_rgba(0,0,0,0.5)]">
            <div className="w-full max-w-lg mx-auto flex items-center justify-around gap-1 font-sans">
              
              {/* HOME WITH GANESHA LOGO */}
              <button
                onClick={() => {
                  setActiveTab("catalog");
                  setSearchQuery("");
                  setSelectedStyle("All");
                  setPriceRange(15000);
                  setSelectedQuality("All");
                  setShowQuickSettings(false);
                  setShowQuickProfile(false);
                  setShowCartDrawer(false);
                  setShowBookingsModal(false);
                }}
                className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-all active:scale-90 ${
                  isHomeActive ? "text-orange-500 font-extrabold" : "text-orange-500/55"
                }`}
              >
                <div className="relative">
                  <span className="text-[10px] absolute -top-1 -right-2 transform translate-x-1/2 -translate-y-1/2">🕉️</span>
                  <Home className="w-5 h-5 text-current" />
                </div>
                <span className="text-[10px] font-bold mt-1 text-current">Home</span>
              </button>

              {/* CART WITH BADGE */}
              <button
                onClick={() => {
                  setShowCartDrawer(true);
                  setShowQuickSettings(false);
                  setShowQuickProfile(false);
                  setShowBookingsModal(false);
                }}
                className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-all active:scale-90 ${
                  isCartActive ? "text-orange-500 font-extrabold" : "text-orange-500/55"
                }`}
              >
                <div className="relative">
                  <ShoppingCart className="w-5 h-5 text-current" />
                  {cart && (
                    <span className="absolute -top-1.5 -right-2 bg-yellow-400 text-orange-950 text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center leading-none border border-black shadow">
                      1
                    </span>
                  )}
                </div>
                <span className="text-[10px] font-bold mt-1 text-current">Cart</span>
              </button>

              {/* ORDER WORKFLOW HISTORY */}
              <button
                onClick={() => {
                  setShowBookingsModal(true);
                  setShowQuickSettings(false);
                  setShowQuickProfile(false);
                  setShowCartDrawer(false);
                }}
                className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-all active:scale-90 ${
                  isOrdersActive ? "text-orange-500 font-extrabold" : "text-orange-500/55"
                }`}
              >
                <div className="relative">
                  <Calendar className="w-5 h-5 text-current" />
                  {currentUser && userOrders.length > 0 && (
                    <span className="absolute -top-1.5 -right-2 bg-orange-600 text-white text-[8px] font-bold px-1 rounded-full leading-none border border-black animate-pulse">
                      {userOrders.length}
                    </span>
                  )}
                </div>
                <span className="text-[10px] font-bold mt-1 text-current max-w-[45px] truncate">Orders</span>
              </button>

              {/* PREFERENCES SETTINGS POPUP */}
              <button
                onClick={() => {
                  setShowQuickSettings(!showQuickSettings);
                  setShowQuickProfile(false);
                  setShowCartDrawer(false);
                  setShowBookingsModal(false);
                }}
                className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-all active:scale-90 ${
                  isSettingsActive ? "text-orange-500 font-extrabold pb-0.5" : "text-orange-500/55"
                }`}
              >
                <Settings className="w-5 h-5 text-current" />
                <span className="text-[10px] font-bold mt-1 text-current">Settings</span>
              </button>

              {/* PROFILE DETAILED TAB */}
              <button
                onClick={() => {
                  setShowQuickProfile(!showQuickProfile);
                  setShowQuickSettings(false);
                  setShowCartDrawer(false);
                  setShowBookingsModal(false);
                }}
                className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-all active:scale-90 ${
                  isProfileActive ? "text-orange-500 font-extrabold pb-0.5" : "text-orange-500/55"
                }`}
              >
                <div className="relative">
                  <User className="w-5 h-5 text-current" />
                  {currentUser && (
                    <span className="absolute bottom-0 right-0 w-2 h-2 bg-green-400 border border-black rounded-full" />
                  )}
                </div>
                <span className="text-[10px] font-bold mt-1 text-current">Profile</span>
              </button>

            </div>
          </div>
        );
      })()}
    </div>
  );
}
