import React, { useState } from "react";
import { Idol, PoojaItem, Order, AppState, AppSettings } from "../types";
import { Plus, Tag, Trash2, CheckCircle2, ChevronRight, X, AlertTriangle, Upload, ShoppingBag, Package, DollarSign, Eye, Settings, Lock, FileText, Phone } from "lucide-react";

interface AdminPanelProps {
  appState: AppState;
  onAddUpdateIdol: (idol: Idol) => void;
  onDeleteIdol: (id: string) => void;
  onUpdateOrderStatus: (orderId: string, status: "completed" | "cancelled") => void;
  onUpdatePoojaItemPrice: (id: string, price: number) => void;
  onUpdateSettings: (settings: AppSettings) => void;
  isSimulatorView?: boolean;
}

export default function AdminPanel({
  appState,
  onAddUpdateIdol,
  onDeleteIdol,
  onUpdateOrderStatus,
  onUpdatePoojaItemPrice,
  onUpdateSettings,
  isSimulatorView = false
}: AdminPanelProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newIdol, setNewIdol] = useState<Partial<Idol>>({
    name: "",
    price: 3000,
    discount: 0,
    style: "Shadu Clay",
    color: "Traditional Orange",
    quality: "Vedic Pure Handcrafted",
    height: "12 inches",
    stock: 5,
    description: "",
    deliveryProvided: true,
    deliveryCharge: 200,
    secondaryImages: []
  });

  const [dragActive, setDragActive] = useState(false);
  const [uploadedBase64Images, setUploadedBase64Images] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<"inventory" | "orders" | "settings">("inventory");
  const [editingPoojaId, setEditingPoojaId] = useState<string | null>(null);
  const [editingPoojaPrice, setEditingPoojaPrice] = useState<number>(0);

  // Admin Secure Login & Locks
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    if (typeof window !== "undefined") {
      return sessionStorage.getItem("vighnaharta-auth-admin") === "true";
    }
    return false;
  });
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // UPI and Whatsapp Configuration states
  const [settUpiId, setSettUpiId] = useState(appState.settings?.adminUpiId || "prathmg1991@okaxis");
  const [settUpiName, setSettUpiName] = useState(appState.settings?.adminUpiName || "Vighnaharta Utsav Akurdi Hub");
  const [settWaNumber, setSettWaNumber] = useState(appState.settings?.adminWhatsappNumber || "919876543210");
  const [settingsSuccess, setSettingsSuccess] = useState(false);

  // Live automatic WhatsApp tracking log state
  const [waLogs, setWaLogs] = useState<any[]>([]);

  // Bulk multipack generator tabs choice
  const [addFormMode, setAddFormMode] = useState<"single" | "bulk">("single");
  const [bulkTitle, setBulkTitle] = useState("Artisanal eco-Mati Ganesha");
  const [bulkStyle, setBulkStyle] = useState("Shadu Clay");
  const [bulkQuality, setBulkQuality] = useState("Vedic Pure Handcrafted");
  const [bulkHeight, setBulkHeight] = useState("18 inches");
  const [bulkColor, setBulkColor] = useState("Saffron Gold Multicolor");
  const [bulkPrice, setBulkPrice] = useState(3500);
  const [bulkCount, setBulkCount] = useState(5);

  // Synchronize remote settings on update
  React.useEffect(() => {
    if (appState.settings) {
      setSettUpiId(appState.settings.adminUpiId);
      setSettUpiName(appState.settings.adminUpiName);
      setSettWaNumber(appState.settings.adminWhatsappNumber);
    }
  }, [appState.settings]);

  // Read remote WhatsApp audit logs
  const fetchWaLogs = async () => {
    try {
      const res = await fetch("/api/whatsapp/logs");
      if (res.ok) {
        const data = await res.json();
        setWaLogs(data);
      }
    } catch (e) {
      console.error("Error reading WhatsApp notification logs:", e);
    }
  };

  React.useEffect(() => {
    if (activeTab === "settings" && isAuthenticated) {
      fetchWaLogs();
    }
  }, [activeTab, isAuthenticated]);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setIsAuthenticated(true);
          sessionStorage.setItem("vighnaharta-auth-admin", "true");
        }
      } else {
        const errorData = await res.json();
        setLoginError(errorData.error || "Access Denied. Secret keys mismatch.");
      }
    } catch (err) {
      setLoginError("Failed to communicate with authentication gateway.");
    }
  };

  const handleSettingsSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settUpiId || !settUpiName) return;

    onUpdateSettings({
      adminUpiId: settUpiId,
      adminUpiName: settUpiName,
      adminWhatsappNumber: settWaNumber
    });

    setSettingsSuccess(true);
    setTimeout(() => setSettingsSuccess(false), 2500);
  };

  const handleBulkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bulkTitle || !bulkPrice || bulkCount < 1) return;

    // Automatically map preset stock images sequentially
    for (let i = 0; i < bulkCount; i++) {
        const presetImg = PRESET_MOCK_IMAGES[i % PRESET_MOCK_IMAGES.length].url;
        const generatedIdol: Idol = {
          id: `idol-bulk-${Date.now()}-${i}-${Math.floor(Math.random() * 9000)}`,
          name: `${bulkTitle} (Batch Series #${i + 1})`,
          imgUrl: presetImg,
          price: Number(bulkPrice),
          discount: 0,
          style: bulkStyle,
          color: bulkColor,
          quality: bulkQuality,
          height: bulkHeight,
          stock: 4 + (i % 3), // Varied ready stock levels
          description: `Vedic-blessed organic Ganesha. Environmentally certified Shadu clay, modeled sequentially in the style of ${bulkStyle} under ${bulkQuality} norms. Height parameter of ${bulkHeight} featuring deep ${bulkColor} elements.`,
          deliveryProvided: true,
          deliveryCharge: 180,
          secondaryImages: [presetImg]
        };
        onAddUpdateIdol(generatedIdol);
    }

    setSettingsSuccess(true);
    setTimeout(() => setSettingsSuccess(false), 2500);
    setShowAddForm(false);
  };

  // Pre-loaded stunning Ganesha vector mockups in case the user doesn't have local Ganesha images to upload!
  const PRESET_MOCK_IMAGES = [
    {
      name: "Saffron Eco Clay Mock",
      url: "/src/assets/images/eco_clay_ganesha_1781947452568.jpg"
    },
    {
      name: "Polished Brass Mock",
      url: "/src/assets/images/brass_ganesha_1781947467841.jpg"
    },
    {
      name: "Ivory Marble Mock",
      url: "/src/assets/images/marble_ganesha_1781947482119.jpg"
    }
  ];

  // Helper: process multiple files
  const handleFiles = (files: FileList) => {
    const promises: Promise<string>[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type.startsWith("image/")) {
        promises.push(
          new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = (e) => {
              resolve(e.target?.result as string);
            };
            reader.readAsDataURL(file);
          })
        );
      }
    }

    Promise.all(promises).then((base64Strings) => {
      setUploadedBase64Images((prev) => [...prev, ...base64Strings]);
    });
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  const removeUploadedImage = (index: number) => {
    setUploadedBase64Images((prev) => prev.filter((_, i) => i !== index));
  };

  const handlePresetSelect = (url: string) => {
    setUploadedBase64Images((prev) => {
      if (prev.includes(url)) return prev;
      return [...prev, url];
    });
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIdol.name || !newIdol.price) return;

    // Use first uploaded image or a fallback
    const mainImg = uploadedBase64Images[0] || "/src/assets/images/eco_clay_ganesha_1781947452568.jpg";

    const completedIdol: Idol = {
      id: `idol-${Date.now()}`,
      name: newIdol.name,
      imgUrl: mainImg,
      price: Number(newIdol.price),
      discount: Number(newIdol.discount || 0),
      style: newIdol.style || "Shadu Clay",
      color: newIdol.color || "Multicolor",
      quality: newIdol.quality || "Premium Vedic Pure",
      height: newIdol.height || "15 inches",
      stock: Number(newIdol.stock || 5),
      description: newIdol.description || `${newIdol.name} - meticulously designed sacred divine piece.`,
      deliveryProvided: !!newIdol.deliveryProvided,
      deliveryCharge: Number(newIdol.deliveryCharge || 0),
      secondaryImages: uploadedBase64Images.length > 0 ? uploadedBase64Images : [mainImg]
    };

    onAddUpdateIdol(completedIdol);

    // Reset Form
    setNewIdol({
      name: "",
      price: 3000,
      discount: 0,
      style: "Shadu Clay",
      color: "Traditional Orange",
      quality: "Vedic Pure Handcrafted",
      height: "12 inches",
      stock: 5,
      description: "",
      deliveryProvided: true,
      deliveryCharge: 200,
      secondaryImages: []
    });
    setUploadedBase64Images([]);
    setShowAddForm(false);
  };

  const savePoojaPrice = (id: string) => {
    onUpdatePoojaItemPrice(id, editingPoojaPrice);
    setEditingPoojaId(null);
  };

  if (!isAuthenticated) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-4 text-center select-none animate-fadeIn max-w-[390px] mx-auto min-h-[460px]">
        <div className="bg-purple-950/85 border-2 border-yellow-300/30 p-5 rounded-3xl shadow-2xl relative backdrop-blur-md text-white w-full">
          <span className="text-4xl block animate-bounce mb-2">🌺🕉️🔑</span>
          <h2 className="text-base font-black text-yellow-300 font-sans">Administrative Vault Lock</h2>
          <p className="text-[10px] text-white/70 mt-1 mb-4 leading-normal">
            Enter standard administrative secret credentials to customize merchant UPI paths, trigger bill templates, and access backend logs.
          </p>

          <form onSubmit={handleLoginSubmit} className="space-y-3.5 text-left text-xs">
            <div>
              <label className="block text-[9px] uppercase font-bold tracking-wider text-yellow-300/80 mb-1">Admin Username</label>
              <input
                type="text"
                placeholder="Enter 'admin'"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-black/45 border border-white/10 p-2 rounded-lg text-white outline-none focus:ring-1 focus:ring-yellow-400 placeholder-white/25 font-mono"
              />
            </div>

            <div>
              <label className="block text-[9px] uppercase font-bold tracking-wider text-yellow-300/80 mb-1">Secret Keyphrase</label>
              <input
                type="password"
                placeholder="Enter 'admin'"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-black/45 border border-white/10 p-2 rounded-lg text-white outline-none focus:ring-1 focus:ring-yellow-400 placeholder-white/25 font-mono"
              />
            </div>

            {loginError && (
              <p className="text-red-400 font-bold text-[9px] animate-pulse flex items-center gap-1 bg-red-400/10 p-2 rounded-lg border border-red-500/10">
                ⚠️ {loginError}
              </p>
            )}

            <button
              type="submit"
              className="w-full bg-yellow-400 hover:bg-yellow-300 border border-yellow-300 text-orange-950 font-black py-2 rounded-lg cursor-pointer font-sans shadow-lg uppercase tracking-wide"
            >
              Unlocked Divine Console
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className={`h-full flex flex-col ${isSimulatorView ? "text-[12px] p-2 bg-transparent" : "p-6 text-white"}`}>
      {/* Title block */}
      {!isSimulatorView && (
        <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between border-b border-white/10 pb-4">
          <div>
            <h1 className="text-2xl font-black tracking-tight text-yellow-300 font-sans flex items-center gap-2">
              <Package className="w-6 h-6 text-yellow-300" />
              Ganesha Divine Inventory Console
            </h1>
            <p className="text-xs text-white/60 font-mono mt-1">
              Admin Portal • Real-Time Synchronization Enabled
            </p>
          </div>
          <div className="flex gap-2 mt-4 md:mt-0 font-mono">
            <button
              onClick={() => setActiveTab("inventory")}
              className={`px-4 py-2 text-xs font-black rounded-lg border transition-all cursor-pointer ${
                activeTab === "inventory"
                  ? "bg-yellow-400 border-yellow-300 text-orange-950 shadow-md shadow-yellow-400/20 font-sans"
                  : "bg-white/10 border-white/10 hover:bg-white/15 text-white/90"
              }`}
            >
              Inventory ({appState.idols.length})
            </button>
            <button
              onClick={() => setActiveTab("orders")}
              className={`px-4 py-2 text-xs font-black rounded-lg border transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === "orders"
                  ? "bg-yellow-400 border-yellow-300 text-orange-950 shadow-md shadow-yellow-400/20 font-sans"
                  : "bg-white/10 border-white/10 hover:bg-white/15 text-white/90"
              }`}
            >
              Bookings Ledger ({appState.orders.length})
              {appState.orders.some((o) => o.status === "booked") && (
                <span className="w-2 h-2 rounded-full bg-red-550 animate-ping inline-block bg-red-400" />
              )}
            </button>
            <button
              onClick={() => {
                setActiveTab("settings");
                fetchWaLogs();
              }}
              className={`px-4 py-2 text-xs font-black rounded-lg border transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === "settings"
                  ? "bg-yellow-400 border-yellow-300 text-orange-950 shadow-md shadow-yellow-400/20 font-sans"
                  : "bg-white/10 border-white/10 hover:bg-white/15 text-white/90"
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              Merchant Control
            </button>
          </div>
        </div>
      )}

      {/* Simulator Device Header (Compact version) */}
      {isSimulatorView && (
        <div className="border-b border-white/10 pb-2 mb-2 flex items-center justify-between">
          <div className="font-sans font-black flex items-center gap-1 text-yellow-300">
            <Package className="w-4 h-4" />
            <span>Admin Control</span>
          </div>
          <div className="flex bg-black/30 rounded-md p-0.5 border border-white/10 gap-0.5 text-[10px]">
            <button
              onClick={() => setActiveTab("inventory")}
              className={`px-1.5 py-0.5 rounded font-mono cursor-pointer ${
                activeTab === "inventory" ? "bg-yellow-400 text-orange-950 font-black" : "text-white/60 hover:text-white"
              }`}
            >
              Idols ({appState.idols.length})
            </button>
            <button
              onClick={() => setActiveTab("orders")}
              className={`px-1.5 py-0.5 rounded font-mono cursor-pointer ${
                activeTab === "orders" ? "bg-yellow-400 text-orange-950 font-black" : "text-white/60 hover:text-white"
              }`}
            >
              Ledger ({appState.orders.length})
            </button>
            <button
              onClick={() => {
                setActiveTab("settings");
                fetchWaLogs();
              }}
              className={`px-1.5 py-0.5 rounded font-mono cursor-pointer ${
                activeTab === "settings" ? "bg-yellow-400 text-orange-950 font-black" : "text-white/60 hover:text-white"
              }`}
            >
              Setup
            </button>
          </div>
        </div>
      )}

      {/* Primary Panels */}
      <div className="flex-1 overflow-y-auto pr-1">
        {activeTab === "inventory" ? (
          <div className="space-y-4">
            {/* Header with quick creation action */}
            <div className="flex items-center justify-between">
              <span className={`font-mono text-white/60 ${isSimulatorView ? 'text-[10px]' : 'text-xs'}`}>
                Managing Ganesha Idols Inventory
              </span>
              <button
                onClick={() => setShowAddForm(true)}
                className={`bg-yellow-400 hover:bg-yellow-300 text-orange-950 flex items-center gap-1 font-black rounded-lg cursor-pointer shadow-md ${
                  isSimulatorView ? "px-2 py-1 text-[10px]" : "px-3.5 py-1.5 text-xs font-mono"
                }`}
              >
                <Plus className="w-3.5 h-3.5" />
                Add New Idol
              </button>
            </div>

            {/* List of Idols */}
            <div className="grid grid-cols-1 gap-3">
              {appState.idols.map((idol) => {
                const discountedPrice = idol.price - (idol.price * (idol.discount / 100));
                return (
                  <div
                    key={idol.id}
                    className="p-3 bg-purple-950/40 backdrop-blur-sm border border-white/15 rounded-xl flex items-start gap-3 relative overflow-hidden shadow-md group hover:border-yellow-300/40 hover:bg-purple-950/50 transition-all duration-300 text-white"
                  >
                    {/* Item Image */}
                    <div className="w-[80px] h-[80px] relative rounded-lg overflow-hidden bg-black flex-shrink-0">
                      <img
                        src={idol.imgUrl}
                        alt={idol.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      {idol.discount > 0 && (
                        <div className="absolute top-0 left-0 bg-red-650 text-white text-[9px] font-black px-1.5 py-0.5 rounded-br font-mono bg-pink-600">
                          {idol.discount}% OFF
                        </div>
                      )}
                    </div>

                    {/* Details in columns */}
                    <div className="flex-1 min-w-0 flex flex-col justify-between h-full">
                      <div>
                        <div className="flex items-start justify-between gap-1">
                          <h3 className="font-extrabold text-white truncate text-[13px]">{idol.name}</h3>
                          <button
                            onClick={() => onDeleteIdol(idol.id)}
                            className="text-white/60 hover:text-red-400 cursor-pointer self-start p-1 bg-white/10 hover:bg-red-950/40 rounded border border-white/10 transition-all"
                            title="Remove completely"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <p className="text-[10px] text-white/70 font-mono flex items-center gap-1.5 mt-0.5">
                          <span>Style: <strong className="text-yellow-300 font-bold">{idol.style}</strong></span>
                          <span>•</span>
                          <span>Size: <strong className="text-yellow-300 font-bold">{idol.height}</strong></span>
                        </p>
                      </div>

                      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-white/10 pt-2">
                        {/* Price Controls & Discounts */}
                        <div className="flex items-center gap-2">
                          <div className="flex flex-col">
                            <span className="text-[9px] text-white/50 uppercase leading-none">Price</span>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              {idol.discount > 0 ? (
                                <>
                                  <span className="font-extrabold text-yellow-300 font-mono">₹{discountedPrice}</span>
                                  <span className="text-white/40 line-through text-[10px] font-mono">₹{idol.price}</span>
                                </>
                              ) : (
                                <span className="font-extrabold text-yellow-300 font-mono">₹{idol.price}</span>
                              )}
                            </div>
                          </div>

                          {/* Quick Adjust Discount Option */}
                          <div className="flex flex-col ml-3 pl-3 border-l border-white/10">
                            <span className="text-[9px] text-white/50 uppercase leading-none">Discount</span>
                            <div className="flex items-center gap-1 mt-0.5">
                              <input
                                type="number"
                                min="0"
                                max="99"
                                value={idol.discount}
                                onChange={(e) => {
                                  const disc = Math.min(99, Math.max(0, parseInt(e.target.value) || 0));
                                  onAddUpdateIdol({ ...idol, discount: disc });
                                }}
                                className="w-[36px] bg-black/40 border border-white/15 text-center font-mono rounded text-white text-[10px] py-0.5 h-5 outline-none focus:ring-1 focus:ring-yellow-400"
                              />
                              <span className="text-[10px] text-white/50 font-mono">%</span>
                            </div>
                          </div>
                        </div>

                        {/* Stock Level Controls */}
                        <div className="flex items-center gap-3">
                          <div className="flex flex-col">
                            <span className="text-[9px] text-white/50 uppercase leading-none">Delivery options</span>
                            <button
                              onClick={() => {
                                onAddUpdateIdol({ ...idol, deliveryProvided: !idol.deliveryProvided });
                              }}
                              className={`text-[10px] font-mono mt-0.5 text-left font-black cursor-pointer ${
                                idol.deliveryProvided ? "text-green-300" : "text-yellow-300/80"
                              }`}
                            >
                              {idol.deliveryProvided ? "Home Delivery" : "Pickup Only"}
                            </button>
                          </div>

                          <div className="flex flex-col">
                            <span className="text-[9px] text-white/50 uppercase leading-none">Inventory Stock</span>
                            <div className="flex items-center gap-1.5 mt-0.5 bg-black/30 p-0.5 rounded border border-white/10">
                              <button
                                onClick={() => {
                                  if (idol.stock > 0) onAddUpdateIdol({ ...idol, stock: idol.stock - 1 });
                                }}
                                className="px-1.5 bg-white/10 text-[10px] rounded hover:bg-white/20 text-white font-bold border border-white/10"
                              >
                                -
                              </button>
                              <span className={`font-mono font-bold text-[10px] px-1 min-w-[14px] text-center ${
                                idol.stock === 0 ? "text-pink-400 font-black" : "text-white"
                              }`}>
                                {idol.stock}
                              </span>
                              <button
                                onClick={() => {
                                  onAddUpdateIdol({ ...idol, stock: idol.stock + 1 });
                                }}
                                className="px-1.5 bg-white/10 text-[10px] rounded hover:bg-white/20 text-white font-bold border border-white/10"
                              >
                                +
                              </button>
                            </div>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Pooja Items Price Configurations */}
            <div className="border-t border-white/10 pt-4 mt-6">
              <h3 className="font-extrabold text-yellow-300 text-[13px] font-sans flex items-center gap-1.5 mb-2">
                <Tag className="w-4 h-4 text-yellow-300" />
                Pooja Items Price Management
              </h3>
              <p className="text-[10px] text-white/60 mb-3 font-mono">
                Updates here propagate to added user recommendations and cart calculations.
              </p>
              <div className="bg-black/35 backdrop-blur-sm rounded-xl p-2.5 border border-white/10 space-y-2">
                {appState.poojaItems.map((pi) => (
                  <div key={pi.id} className="flex items-center justify-between text-white/90 text-[11px] font-mono border-b border-white/5 pb-1.5 last:border-0 last:pb-0">
                    <span className="flex items-center gap-1 truncate max-w-[200px]">
                      <span>{pi.icon}</span>
                      <span className="truncate">{pi.name}</span>
                    </span>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      {editingPoojaId === pi.id ? (
                        <>
                           <span className="text-white/50">₹</span>
                          <input
                            type="number"
                            value={editingPoojaPrice}
                            onChange={(e) => setEditingPoojaPrice(parseInt(e.target.value) || 0)}
                            className="bg-black/40 border border-white/15 text-white font-mono w-[60px] px-1 py-0.5 rounded text-[10px] text-center outline-none focus:ring-1 focus:ring-yellow-400"
                          />
                          <button
                            onClick={() => savePoojaPrice(pi.id)}
                            className="bg-green-500 hover:bg-green-400 text-white border border-green-500 px-2 py-0.5 rounded text-[10px] cursor-pointer font-extrabold shadow-sm"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingPoojaId(null)}
                            className="text-white/60 hover:text-white px-1 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </>
                      ) : (
                        <>
                          <span className="font-bold text-yellow-300">₹{pi.price}</span>
                          <button
                            onClick={() => {
                              setEditingPoojaId(pi.id);
                              setEditingPoojaPrice(pi.price);
                            }}
                            className="text-white/65 hover:text-yellow-300 text-[10px] underline ml-2 cursor-pointer"
                          >
                            Edit
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : activeTab === "orders" ? (
          /* Bookings/Orders ledger panel */
          <div className="space-y-4">
            <span className="font-mono text-xs text-white/60">
              Divine Orders Tracker • Live Updates
            </span>

            {appState.orders.length === 0 ? (
              <div className="p-8 text-center bg-black/35 border border-white/10 rounded-2xl flex flex-col items-center justify-center">
                <ShoppingBag className="w-8 h-8 text-white/20 mb-2" />
                <p className="text-white/70 font-black text-xs">No active bookings yet.</p>
                <p className="text-[10px] text-white/50 mt-1 max-w-[200px] leading-relaxed">
                  Bookings created in Customer screens instantly show up here in real time.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {[...appState.orders].reverse().map((order) => (
                  <div
                    key={order.id}
                    className={`p-3 bg-purple-950/40 border rounded-xl relative transition-all duration-300 backdrop-blur-sm ${
                      order.status === "booked"
                        ? "border-yellow-300/35"
                        : order.status === "completed"
                        ? "border-white/10 opacity-75"
                        : "border-pink-900/30 opacity-60"
                    }`}
                  >
                    {/* Top status header */}
                    <div className="flex items-center justify-between text-[11px] font-mono pb-1.5 border-b border-white/10">
                      <span className="text-yellow-300 font-extrabold">{order.id}</span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-white/60 text-[10px]">
                          Device: {order.deviceId}
                        </span>
                        <span>•</span>
                        <span
                          className={`font-black px-1.5 py-0.5 rounded text-[8px] uppercase tracking-wide inline-block ${
                            order.status === "booked"
                              ? "bg-yellow-400/15 text-yellow-300 border border-yellow-300/20"
                              : order.status === "completed"
                              ? "bg-green-500/20 text-green-300 border border-green-500/30"
                              : "bg-pink-500/15 text-pink-300 border border-pink-500/20"
                          }`}
                        >
                          {order.status}
                        </span>
                      </div>
                    </div>

                    {/* Customer details & purchase Ganesha details */}
                    <div className="mt-2.5 flex items-start gap-3">
                      <img
                        src={order.idolImg}
                        className="w-[48px] h-[48px] rounded object-cover bg-black"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 min-w-0 font-sans text-xs">
                        <h4 className="font-extrabold text-white leading-tight">
                          Booked: {order.idolName}
                        </h4>
                        <p className="text-white/70 mt-0.5 font-sans">
                          Buyer: <strong className="text-white font-black">{order.customerName}</strong> ({order.customerPhone})
                        </p>
                        <p className="text-white/70 mt-0.5 font-medium flex items-center gap-1 font-mono text-[10px]">
                          <span className={order.deliveryType === "delivery" ? "text-purple-300 font-extrabold" : "text-yellow-350"}>
                            {order.deliveryType === "delivery" ? "🚚 Home Delivery Requested" : "🚶 Self-Pickup Scheduled"}
                          </span>
                        </p>
                      </div>
                    </div>

                    {/* Extras and pooja details */}
                    {order.poojaItems && order.poojaItems.length > 0 && (
                      <div className="mt-2.5 bg-black/35 p-2 rounded-lg font-mono text-[10px] text-white/70 space-y-1 border border-white/5">
                        <span className="text-[9px] uppercase text-white/40 font-bold block">Pooja Accessories:</span>
                        {order.poojaItems.map((item, idx) => (
                          <div key={idx} className="flex justify-between">
                            <span>- {item.name} (x{item.quantity})</span>
                            <span className="text-white font-semibold">₹{item.price * item.quantity}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Financial breakdowns */}
                    <div className="mt-2.5 flex flex-wrap items-center justify-between gap-1.5 pt-2.5 border-t border-white/10 font-mono text-[11px]">
                      <div>
                        <p className="text-[10px] text-white/50 leading-none">Financial Invoice</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-white/80">Total: ₹{order.totalAmount}</span>
                          <span className="text-white/30">|</span>
                          <span className="text-green-300 font-extrabold">Paid: ₹{order.paymentAmount}</span>
                          {order.remainingAmount > 0 && (
                            <>
                              <span className="text-white/30">|</span>
                              <span className="text-pink-300 font-semibold" title="Pay while pickup">
                                Pending: ₹{order.remainingAmount} (At pickup)
                              </span>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Action buttons */}
                      {order.status === "booked" && (
                        <div className="flex gap-1">
                          <button
                            onClick={() => onUpdateOrderStatus(order.id, "completed")}
                            className="bg-green-500 hover:bg-green-400 text-white font-extrabold px-2.5 py-1 rounded text-[10px] cursor-pointer shadow-sm"
                          >
                            Complete
                          </button>
                          <button
                            onClick={() => onUpdateOrderStatus(order.id, "cancelled")}
                            className="bg-white/10 hover:bg-red-950/40 text-red-300 border border-white/10 hover:border-red-900/50 hover:text-white px-2 py-1 rounded text-[10px] cursor-pointer font-bold"
                            title="Cancel Order & Refill Stock"
                          >
                            Cancel
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* Settings / Merchant setup panel */
          <div className="space-y-4 animate-fadeIn">
            <div className="bg-yellow-405/10 bg-yellow-400/10 border border-yellow-300/25 rounded-2xl p-3.5 mb-2">
              <span className="text-[10px] font-sans text-yellow-300 font-extrabold flex items-center gap-1 uppercase tracking-wide">
                <Settings className="w-3.5 h-3.5" /> Merchant UPI Gateway & Bot Setup
              </span>
              <p className="text-[10px] text-white/80 leading-normal mt-1">
                Customize secure reservation details. Updates dynamically adjust QR codes on both Device A and Device B!
              </p>
            </div>

            <form onSubmit={handleSettingsSave} className="space-y-3.5 bg-black/40 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[9px] uppercase font-bold tracking-widest text-yellow-300/80 mb-1">Merchant UPI Address (Real UPI)</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. UPI@bank"
                    value={settUpiId}
                    onChange={(e) => setSettUpiId(e.target.value)}
                    className="w-full bg-black/45 border border-white/10 p-2 rounded-lg text-xs font-mono text-white outline-none focus:ring-1 focus:ring-yellow-400"
                  />
                  <span className="text-[9px] text-white/40 font-mono mt-0.5 block">QR codes will point payments here directly.</span>
                </div>

                <div>
                  <label className="block text-[9px] uppercase font-bold tracking-widest text-yellow-300/80 mb-1">Recipient/Business Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Vighnaharta Hub"
                    value={settUpiName}
                    onChange={(e) => setSettUpiName(e.target.value)}
                    className="w-full bg-black/45 border border-white/10 p-2 rounded-lg text-xs font-mono text-white outline-none focus:ring-1 focus:ring-yellow-400"
                  />
                  <span className="text-[9px] text-white/40 font-mono mt-0.5 block">UPI transaction recipient alias name.</span>
                </div>
              </div>

              <div>
                <label className="block text-[9px] uppercase font-bold tracking-widest text-yellow-300/80 mb-1">Admin Alert Whatsapp Number</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 919876543210"
                  value={settWaNumber}
                  onChange={(e) => setSettWaNumber(e.target.value)}
                  className="w-full bg-black/45 border border-white/10 p-2 rounded-lg text-xs font-mono text-white outline-none focus:ring-1 focus:ring-yellow-400"
                />
                <span className="text-[9px] text-white/45 font-mono mt-0.5 block">System forwards automatic alert copies to this administrator WhatsApp line.</span>
              </div>

              {settingsSuccess && (
                <div className="p-2 rounded bg-green-500/15 border border-green-500/30 text-green-300 font-bold text-[10px] text-center animate-bounce flex items-center justify-center gap-1">
                  ❇️ Configurations Synced and Saved to Server Permanently!
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-300 border border-yellow-300 text-orange-950 font-black py-2 rounded-lg cursor-pointer text-xs uppercase tracking-wider font-sans transition-all flex items-center justify-center gap-1 shadow-md shadow-yellow-400/10"
              >
                🌺 Deploy Portal Changes
              </button>
            </form>

            {/* Live WhatsApp Audit Feed Logs */}
            <div className="bg-black/45 p-3.5 rounded-2xl border border-white/10">
              <div className="flex items-center justify-between pb-2 border-b border-white/5 mb-3">
                <div className="flex items-center gap-1.5 font-sans">
                  <Phone className="w-4 h-4 text-green-400 animate-pulse" />
                  <div>
                    <h4 className="text-[11px] font-sans font-extrabold text-white leading-normal">Live Dispatched WhatsApp Billing Stream</h4>
                    <p className="text-[9px] font-mono text-white/45">Failsafe notification verification monitor</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={fetchWaLogs}
                  className="px-2 py-0.5 bg-white/10 hover:bg-white/15 text-white/85 rounded font-mono text-[9px] transition-all cursor-pointer border border-white/5"
                >
                  Refresh Logs
                </button>
              </div>

              {waLogs.length === 0 ? (
                <div className="py-6 text-center text-white/35 font-mono text-[10px]">
                  💤 No dispatch records parsed yet. Complete a checkout booking above to trigger WhatsApp dispatch codes!
                </div>
              ) : (
                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                  {[...waLogs].reverse().map((log: any, index: number) => (
                    <div key={index} className="p-2 bg-purple-950/20 border border-white/5 rounded-lg text-[9px] font-mono space-y-1">
                      <div className="flex items-center justify-between text-white/40">
                        <span>{log.timestamp}</span>
                        <span className="text-[8px] bg-green-500/20 text-green-300 px-1 py-0.2 rounded border border-green-500/25 uppercase font-bold">Successfully Dispatched</span>
                      </div>
                      <div className="text-white/90">
                        <strong>To:</strong> {log.targetPhone} ({log.type === "admin" ? "Admin Copy alert" : "Customer invoice copy"})
                      </div>
                      <div className="bg-black/35 p-1.5 rounded text-white/85 whitespace-pre-line border border-white/5 leading-normal text-[10px]">
                        {log.message}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Floating Add New Idol Form Diagonal Screen */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-[999] flex items-center justify-center p-4">
          <div className="bg-purple-950/85 border border-white/20 rounded-2xl w-full max-w-[500px] shadow-2xl max-h-[90vh] flex flex-col font-sans backdrop-blur-xl text-white">
            
            {/* Modal Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-black text-yellow-300 flex items-center gap-1.5 font-sans">
                <Plus className="w-5 h-5 text-yellow-300" />
                Upload New Ganapati Idol
              </h2>
              <button
                onClick={() => {
                  setShowAddForm(false);
                  setUploadedBase64Images([]);
                }}
                className="text-white/60 hover:text-white p-1 rounded-full cursor-pointer hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body Scroll */}
            <div className="p-4 overflow-y-auto space-y-4 flex-1 text-xs">
              {/* Creation Mode Tabs Selection */}
              <div className="flex bg-black/45 rounded-xl p-1 border border-white/10 gap-1 font-mono text-[10px] mb-3">
                <button
                  type="button"
                  onClick={() => setAddFormMode("single")}
                  className={`flex-1 py-1.5 rounded-lg text-center cursor-pointer font-bold ${
                    addFormMode === "single" ? "bg-yellow-405 text-orange-950 font-black bg-yellow-300" : "text-white/60 hover:text-white"
                  }`}
                >
                  Single Ganesha Creation
                </button>
                <button
                  type="button"
                  onClick={() => setAddFormMode("bulk")}
                  className={`flex-1 py-1.5 rounded-lg text-center cursor-pointer font-bold ${
                    addFormMode === "bulk" ? "bg-yellow-405 text-orange-950 font-black bg-yellow-300" : "text-white/60 hover:text-white"
                  }`}
                >
                  Bulk Series Multipack Configurer
                </button>
              </div>

              {addFormMode === "bulk" ? (
                /* BULK SERIES MULTIPACK GENERATOR */
                <form onSubmit={handleBulkSubmit} className="space-y-3.5">
                  <div className="bg-orange-550/10 bg-orange-500/10 border border-orange-400/20 rounded-xl p-3 mb-2 text-white/90 leading-tight">
                    <p className="font-extrabold text-yellow-300 text-xs">⚡ Bulk Series Instant Generator</p>
                    <p className="text-[10px] text-white/70 mt-1 leading-normal">Specify shared properties and titles. All batch variants get generated with sequential series names (e.g. #1, #2...) and ready stocks automatically!</p>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-white/80 font-bold mb-1">Batch Series Base Title</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Sacred Vakratunda Eco Murti"
                        value={bulkTitle}
                        onChange={(e) => setBulkTitle(e.target.value)}
                        className="w-full bg-black/45 border border-white/15 p-2 text-white placeholder-white/30 rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 font-extrabold text-xs"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <label className="block text-white/80 font-semibold mb-1 col-span-1">Style Style</label>
                        <select
                          value={bulkStyle}
                          onChange={(e) => setBulkStyle(e.target.value)}
                          className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400"
                        >
                          <option className="bg-purple-950 text-white" value="Shadu Clay">Vedic Shadu Clay</option>
                          <option className="bg-purple-950 text-white" value="Red Soil">Traditional Red Soil</option>
                          <option className="bg-purple-950 text-white" value="Marble Finish">Luxury Marble Finish</option>
                          <option className="bg-purple-950 text-white" value="Copper Casting">Copper Casting look</option>
                          <option className="bg-purple-950 text-white" value="Brass Gilt">Polished Brass Gilt</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-white/80 font-semibold mb-1 col-span-1 border-0">Craft Quality Level</label>
                        <select
                          value={bulkQuality}
                          onChange={(e) => setBulkQuality(e.target.value)}
                          className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 text-xs"
                        >
                          <option className="bg-purple-950 text-white font-sans" value="Vedic Pure Handcrafted">Vedic Pure Handcrafted</option>
                          <option className="bg-purple-950 text-white font-sans" value="Premium Artisanal Clay">Premium Artisanal Clay</option>
                          <option className="bg-purple-950 text-white font-sans" value="Traditional Heritage Edition">Traditional Heritage Edition</option>
                          <option className="bg-purple-950 text-white font-sans" value="Sanskrit Prana Pratishtha">Sanskrit Prana Pratishtha</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-white/80 font-semibold mb-1">Murti Size</label>
                        <select
                          value={bulkHeight}
                          onChange={(e) => setBulkHeight(e.target.value)}
                          className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 text-xs font-mono"
                        >
                          <option className="bg-purple-950 text-white" value="12 inches">12 inches (Altar scale)</option>
                          <option className="bg-purple-950 text-white" value="18 inches">18 inches (Standard scale)</option>
                          <option className="bg-purple-950 text-white" value="24 inches">24 inches (Majestic scale)</option>
                          <option className="bg-purple-950 text-white" value="36 inches">36 inches (Pandal scale)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-white/80 font-semibold mb-1">Base Paint Accent</label>
                        <select
                          value={bulkColor}
                          onChange={(e) => setBulkColor(e.target.value)}
                          className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 text-xs"
                        >
                          <option className="bg-purple-950 text-white" value="Saffron Gold Multicolor">Saffron Gold Multicolor</option>
                          <option className="bg-purple-950 text-white" value="Pure Natural Earthen Sand">Pure Earthen Sand</option>
                          <option className="bg-purple-950 text-white" value="Traditional Antique Orange">Antique Orange</option>
                          <option className="bg-purple-950 text-white" value="Sacred Ivory Gold">Sacred Ivory Gold</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-white/80 font-semibold mb-1">Price per Murti (₹)</label>
                        <input
                          type="number"
                          required
                          min="100"
                          value={bulkPrice}
                          onChange={(e) => setBulkPrice(parseInt(e.target.value) || 0)}
                          className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 font-mono text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-white/80 font-semibold mb-1">Bulk Size Count</label>
                        <select
                          value={bulkCount}
                          onChange={(e) => setBulkCount(parseInt(e.target.value) || 5)}
                          className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 font-mono text-xs"
                        >
                          <option className="bg-purple-950 text-white" value={3}>3 Ganeshas Series</option>
                          <option className="bg-purple-950 text-white" value={5}>5 Ganeshas Batch</option>
                          <option className="bg-purple-950 text-white" value={10}>10 Ganeshas Multipack</option>
                          <option className="bg-purple-950 text-white" value={15}>15 Majestic Fleet</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Form Actions */}
                  <div className="flex gap-2 mt-4 pt-4 border-t border-white/10">
                    <button
                      type="submit"
                      className="flex-1 bg-yellow-400 hover:bg-yellow-300 border border-yellow-300 text-orange-950 font-black p-2.5 rounded-lg text-xs cursor-pointer font-sans shadow-lg shadow-yellow-400/20"
                    >
                      🌱 Deploy Bulk Ganeshas Series
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowAddForm(false);
                      }}
                      className="bg-white/10 hover:bg-white/15 text-white font-extrabold p-2.5 rounded-lg text-xs cursor-pointer font-sans border border-white/10"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleFormSubmit} className="space-y-4">
                
                {/* Drag and Drop Image Uploader Block */}
                <div className="space-y-1.5">
                  <label className="block text-white/90 font-extrabold font-sans">
                    Idol Images (Drag-Drop / File Upload)
                  </label>
                  <p className="text-[10px] text-white/50 font-mono">
                    You can select or drag several image files. First selected will behave as your display thumbnail.
                  </p>
                  
                  <div
                    onDragEnter={handleDrag}
                    onDragOver={handleDrag}
                    onDragLeave={handleDrag}
                    onDrop={handleDrop}
                    className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all duration-200 relative ${
                      dragActive
                        ? "border-yellow-300 bg-yellow-405/10"
                        : "border-white/10 bg-black/40 hover:bg-black/50 text-white"
                    }`}
                  >
                    <input
                      type="file"
                      id="file-upload-input"
                      multiple
                      accept="image/*"
                      onChange={handleFileInput}
                      className="hidden"
                    />
                    <label htmlFor="file-upload-input" className="cursor-pointer flex flex-col items-center">
                      <Upload className="w-8 h-8 text-yellow-300 mr-2.5 mb-1" />
                      <span className="font-extrabold text-white">Drag & Drop images here</span>
                      <span className="text-white/40 text-[10px] mt-0.5">or click to browse local files</span>
                    </label>
                  </div>

                  {/* Quick Presets in Case of No Images Locally */}
                  <div className="mt-2.5">
                    <span className="text-[10px] font-mono text-white/40 uppercase font-bold block mb-1">
                      Or click pre-generated HD model presets:
                    </span>
                    <div className="flex gap-2.5">
                      {PRESET_MOCK_IMAGES.map((preset, index) => (
                        <button
                          key={index}
                          type="button"
                          onClick={() => handlePresetSelect(preset.url)}
                          className="flex items-center gap-1 p-1 bg-white/10 hover:bg-white/15 text-white rounded text-[9px] border border-white/10 font-mono cursor-pointer"
                        >
                          <Eye className="w-3 h-3 text-yellow-300" />
                          {preset.name}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Thumbnail Previews */}
                  {uploadedBase64Images.length > 0 && (
                    <div className="mt-3">
                      <span className="text-[10px] font-mono text-white/50 uppercase font-bold block mb-1">
                        Loaded Images ({uploadedBase64Images.length}):
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {uploadedBase64Images.map((b64Img, idx) => (
                          <div
                            key={idx}
                            className="w-[50px] h-[50px] relative rounded overflow-hidden border border-yellow-300 bg-black/60 flex-shrink-0"
                          >
                            <img src={b64Img} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            <div className="absolute top-0 right-0 bg-black/85 p-0.5 cursor-pointer" onClick={() => removeUploadedImage(idx)}>
                              <X className="w-3 h-3 text-pink-400 hover:text-white" />
                            </div>
                            {idx === 0 && (
                              <div className="absolute bottom-0 inset-x-0 bg-yellow-405 text-orange-950 font-black text-[7px] text-center uppercase tracking-tighter bg-yellow-300">
                                Display
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Form fields */}
                <div className="grid grid-cols-2 gap-3.5">
                  <div className="col-span-2">
                    <label className="block text-white/80 font-semibold mb-1">Ganesha Model Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Traditional Lal Mati Ganesha"
                      value={newIdol.name}
                      onChange={(e) => setNewIdol({ ...newIdol, name: e.target.value })}
                      className="w-full bg-black/45 border border-white/15 p-2 text-white placeholder-white/30 rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 font-extrabold"
                    />
                  </div>

                  <div>
                    <label className="block text-white/80 font-semibold mb-1">Base Price (₹)</label>
                    <input
                      type="number"
                      required
                      min="100"
                      value={newIdol.price}
                      onChange={(e) => setNewIdol({ ...newIdol, price: parseInt(e.target.value) || 0 })}
                      className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-white/80 font-semibold mb-1">Special Discount (%)</label>
                    <input
                      type="number"
                      min="0"
                      max="95"
                      value={newIdol.discount}
                      onChange={(e) => setNewIdol({ ...newIdol, discount: parseInt(e.target.value) || 0 })}
                      className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-white/80 font-semibold mb-1">Style Style</label>
                    <select
                      value={newIdol.style}
                      onChange={(e) => setNewIdol({ ...newIdol, style: e.target.value })}
                      className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400"
                    >
                      <option className="bg-purple-950 text-white" value="Shadu Clay">Vedic Shadu Clay</option>
                      <option className="bg-purple-950 text-white" value="Red Soil">Traditional Red Soil (Lal Mati)</option>
                      <option className="bg-purple-950 text-white" value="Copper Coating">Copper Casting look</option>
                      <option className="bg-purple-950 text-white" value="Marble Art">Luxury Marble Art</option>
                      <option className="bg-purple-950 text-white" value="Brass Look">Polished Brass Look</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-white/80 font-semibold mb-1">Height (Inches)</label>
                    <input
                      type="text"
                      placeholder="e.g. 15 inches"
                      value={newIdol.height}
                      onChange={(e) => setNewIdol({ ...newIdol, height: e.target.value })}
                      className="w-full bg-black/45 border border-white/15 p-2 text-white placeholder-white/30 rounded-lg outline-none focus:ring-1 focus:ring-yellow-400"
                    />
                  </div>

                  <div>
                    <label className="block text-white/80 font-semibold mb-1">Art Color</label>
                    <input
                      type="text"
                      placeholder="e.g. Saffron Yellow"
                      value={newIdol.color}
                      onChange={(e) => setNewIdol({ ...newIdol, color: e.target.value })}
                      className="w-full bg-black/45 border border-white/15 p-2 text-white placeholder-white/30 rounded-lg outline-none focus:ring-1 focus:ring-yellow-400"
                    />
                  </div>

                  <div>
                    <label className="block text-white/80 font-semibold mb-1">Craft Quality Level</label>
                    <input
                      type="text"
                      placeholder="e.g. Premium Handcrafted"
                      value={newIdol.quality}
                      onChange={(e) => setNewIdol({ ...newIdol, quality: e.target.value })}
                      className="w-full bg-black/45 border border-white/15 p-2 text-white placeholder-white/30 rounded-lg outline-none focus:ring-1 focus:ring-yellow-400"
                    />
                  </div>

                  <div>
                    <label className="block text-white/80 font-semibold mb-1">Initial Stock Count</label>
                    <input
                      type="number"
                      min="1"
                      value={newIdol.stock}
                      onChange={(e) => setNewIdol({ ...newIdol, stock: parseInt(e.target.value) || 0 })}
                      className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-white/80 font-semibold mb-1">Home Delivery Service</label>
                    <select
                      value={newIdol.deliveryProvided ? "yes" : "no"}
                      onChange={(e) => setNewIdol({ ...newIdol, deliveryProvided: e.target.value === "yes" })}
                      className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400"
                    >
                      <option className="bg-purple-950 text-white" value="yes">Provide Home Delivery</option>
                      <option className="bg-purple-950 text-white" value="no">Strictly Self-Pickup Only</option>
                    </select>
                  </div>

                  {newIdol.deliveryProvided && (
                    <div className="col-span-2">
                      <label className="block text-white/80 font-semibold mb-1">Home Delivery Charge (₹)</label>
                      <input
                        type="number"
                        min="0"
                        value={newIdol.deliveryCharge}
                        onChange={(e) => setNewIdol({ ...newIdol, deliveryCharge: parseInt(e.target.value) || 0 })}
                        className="w-full bg-black/45 border border-white/15 p-2 text-white rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 font-mono"
                      />
                    </div>
                  )}

                  <div className="col-span-2">
                    <label className="block text-white/80 font-semibold mb-1">Artisanal Story Description</label>
                    <textarea
                      rows={3}
                      placeholder="Write details about the clay properties, craftsmanship details..."
                      value={newIdol.description}
                      onChange={(e) => setNewIdol({ ...newIdol, description: e.target.value })}
                      className="w-full bg-black/45 border border-white/15 p-2 text-white placeholder-white/30 rounded-lg outline-none focus:ring-1 focus:ring-yellow-400 text-xs"
                    />
                  </div>
                </div>

                {/* Form Actions */}
                <div className="flex gap-2 mt-4 pt-4 border-t border-white/10">
                  <button
                    type="submit"
                    className="flex-1 bg-yellow-400 hover:bg-yellow-300 border border-yellow-300 text-orange-950 font-black p-2.5 rounded-lg text-xs cursor-pointer font-sans shadow-lg shadow-yellow-400/20"
                  >
                    Post Ganesha to Live Inventory
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddForm(false);
                      setUploadedBase64Images([]);
                    }}
                    className="bg-white/10 hover:bg-white/15 text-white font-extrabold p-2.5 rounded-lg text-xs cursor-pointer font-sans border border-white/10"
                  >
                    Cancel
                  </button>
                </div>

              </form>
              )}
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
