export class OmSoundSynth {
  private ctx: AudioContext | null = null;
  private oscLow1: OscillatorNode | null = null;
  private oscLow2: OscillatorNode | null = null;
  private oscMid: OscillatorNode | null = null;
  private filter: BiquadFilterNode | null = null;
  private masterGain: GainNode | null = null;
  public isPlaying: boolean = false;

  constructor() {
    // Lazy initialized on user click interaction
  }

  public toggle(): boolean {
    if (this.isPlaying) {
      this.stop();
      return false;
    } else {
      this.start();
      return true;
    }
  }

  private start() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;

      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0, this.ctx.currentTime);
      
      // Let's create a beautiful warm lowpass filter to remove harsh harmonics
      this.filter = this.ctx.createBiquadFilter();
      this.filter.type = "lowpass";
      this.filter.frequency.setValueAtTime(180, this.ctx.currentTime); // very warm threshold

      // Oscillator 1: Main Sacred Cosmic OM frequency at 136.1 Hz (C#3)
      this.oscLow1 = this.ctx.createOscillator();
      this.oscLow1.type = "sine";
      this.oscLow1.frequency.setValueAtTime(136.1, this.ctx.currentTime);

      // Oscillator 2: Subtle detuned oscillator at 136.4 Hz to create a rich chorus beating drift
      this.oscLow2 = this.ctx.createOscillator();
      this.oscLow2.type = "sawtooth"; // sawtooth passed through low-pass creates a hum with rich resonance
      this.oscLow2.frequency.setValueAtTime(136.4, this.ctx.currentTime);
      const low2Gain = this.ctx.createGain();
      low2Gain.gain.setValueAtTime(0.3, this.ctx.currentTime);

      // Oscillator 3: Harmonic octave at 272.2 Hz
      this.oscMid = this.ctx.createOscillator();
      this.oscMid.type = "sine";
      this.oscMid.frequency.setValueAtTime(272.2, this.ctx.currentTime);
      const midGain = this.ctx.createGain();
      midGain.gain.setValueAtTime(0.15, this.ctx.currentTime);

      // Connect everything
      this.oscLow1.connect(this.filter);
      
      this.oscLow2.connect(low2Gain);
      low2Gain.connect(this.filter);

      this.oscMid.connect(midGain);
      midGain.connect(this.filter);

      this.filter.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);

      // Start nodes
      this.oscLow1.start();
      this.oscLow2.start();
      this.oscMid.start();

      // Smooth fade-in to prevent sharp clicks
      this.masterGain.gain.linearRampToValueAtTime(0.6, this.ctx.currentTime + 1.5);
      
      this.isPlaying = true;
    } catch (e) {
      console.error("Web Audio API failed to load", e);
    }
  }

  private stop() {
    if (!this.ctx || !this.masterGain) return;

    try {
      // Smooth fade-out before stopping to maintain devotional serene mood
      const cur = this.ctx.currentTime;
      this.masterGain.gain.linearRampToValueAtTime(0, cur + 0.8);
      
      setTimeout(() => {
        try {
          this.oscLow1?.stop();
          this.oscLow2?.stop();
          this.oscMid?.stop();
          this.ctx?.close();
        } catch (_) {}
        
        this.oscLow1 = null;
        this.oscLow2 = null;
        this.oscMid = null;
        this.ctx = null;
        this.masterGain = null;
      }, 900);
      
      this.isPlaying = false;
    } catch (e) {
      console.error("Failed to disconnect sound nodes nicely", e);
    }
  }
}
