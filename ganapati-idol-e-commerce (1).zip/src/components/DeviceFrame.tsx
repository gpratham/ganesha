import React from "react";
import { Sparkles, Wifi, Battery, Signal } from "lucide-react";

interface DeviceFrameProps {
  title: string;
  subtitle?: string;
  role: "user" | "admin";
  children: React.ReactNode;
}

export default function DeviceFrame({ title, subtitle, role, children }: DeviceFrameProps) {
  // Simple fake system time
  const [time, setTime] = React.useState("10:08");

  React.useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hrs = now.getHours();
      let mins = now.getMinutes();
      const strMins = mins < 10 ? `0${mins}` : `${mins}`;
      const ampm = hrs >= 12 ? "PM" : "AM";
      const displayHrs = hrs % 12 || 12;
      setTime(`${displayHrs}:${strMins} ${ampm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center bg-white/10 backdrop-blur-md rounded-3xl p-3 border border-white/20 shadow-2xl w-full max-w-[420px] transition-all duration-300 hover:shadow-yellow-300/10">
      {/* Label and Screen Header */}
      <div className="w-full flex items-center justify-between px-3 pb-2 text-xs font-mono text-white">
        <div className="flex items-center gap-1.5">
          <span className={`inline-block w-2.5 h-2.5 rounded-full ${role === 'admin' ? 'bg-yellow-400' : 'bg-green-400'} animate-pulse`} />
          <span className="font-bold uppercase tracking-wider">{title}</span>
        </div>
        {subtitle && <span className="opacity-90 font-bold text-yellow-300">{subtitle}</span>}
      </div>

      {/* Outer Phone Shell */}
      <div className="relative w-full aspect-[9/19] rounded-[2.5rem] bg-black/60 p-[10px] shadow-2xl border-4 border-white/20 flex flex-col overflow-hidden min-h-[680px] backdrop-blur-sm">
        
        {/* Notch / Dynamic Island */}
        <div className="absolute top-[14px] left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-full z-40 flex items-center justify-center border border-white/10">
          <div className="w-3 h-3 rounded-full bg-zinc-800/80 mr-12" />
          <div className="w-1.5 h-1.5 rounded-full bg-blue-900/80" />
        </div>

        {/* Status Bar */}
        <div className="w-full h-8 flex items-center justify-between px-5 text-[11px] font-sans font-medium text-white z-30 pointer-events-none mt-1">
          <span>{time}</span>
          <div className="flex items-center gap-1">
            <Signal className="w-3.5 h-3.5 text-white" />
            <span className="text-[9px] uppercase tracking-tighter mr-0.5 font-bold text-yellow-300">5G</span>
            <Wifi className="w-3.5 h-3.5 text-white" />
            <div className="flex items-center ml-0.5">
              <span className="text-[10px] font-bold leading-none mr-1">98%</span>
              <Battery className="w-[18px] h-[10px] text-green-400 fill-green-400" />
            </div>
          </div>
        </div>

        {/* Phone Glass Screen Screen Body */}
        <div className="flex-1 rounded-[1.8rem] bg-black/45 backdrop-blur-md overflow-hidden flex flex-col relative border border-white/10">
          {children}
        </div>

        {/* Bottom Home Indicator Bar */}
        <div className="w-full h-5 flex items-center justify-center z-30 pointer-events-none bottom-1 absolute left-0 right-0">
          <div className="w-28 h-[5.5px] bg-white/40 rounded-full" />
        </div>
      </div>
    </div>
  );
}
