export interface Idol {
  id: string;
  name: string;
  imgUrl: string;
  price: number;
  discount: number; // percentage (e.g., 10 for 10% off)
  style: string;     // Shadu Clay, Red Soil, Brass, Marble Art, etc.
  color: string;     // Eco Golden, Natural Earth, Ivory White, Multicolor
  quality: string;   // Premium Handcrafted, Vedic Pure, Standard Deluxe
  height: string;    // Size in inches or feet
  stock: number;
  description: string;
  deliveryProvided: boolean;
  deliveryCharge: number;
  secondaryImages: string[]; // multi-image support
}

export interface PoojaItem {
  id: string;
  name: string;
  price: number;
  icon: string;      // emoji or icon representation
  description: string;
}

export interface CartItem {
  idol: Idol;
  poojaItems: { item: PoojaItem; quantity: number }[];
  deliveryType: "pickup" | "delivery";
  paymentType: "advance" | "full";
  customerName?: string;
  customerPhone?: string;
  deliveryAddress?: string;
}

export interface Order {
  id: string;
  deviceId: string;
  customerName: string;
  customerPhone: string;
  idolId: string;
  idolName: string;
  idolImg: string;
  poojaItems: { id: string; name: string; price: number; quantity: number }[];
  deliveryType: "pickup" | "delivery";
  deliveryAddress?: string;
  paymentType: "advance" | "full";
  paymentAmount: number;
  remainingAmount: number;
  totalAmount: number;
  status: "booked" | "completed" | "cancelled";
  timestamp: string;
}

export interface AppSettings {
  adminUpiId: string;
  adminUpiName: string;
  adminWhatsappNumber: string;
}

export interface AppState {
  idols: Idol[];
  poojaItems: PoojaItem[];
  orders: Order[];
  lastUpdated: number;
  settings?: AppSettings;
}

export interface AuthUser {
  email?: string;
  phone?: string;
  displayName?: string;
  token?: string;
}
